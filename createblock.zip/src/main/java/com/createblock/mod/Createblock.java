package com.createblock.mod;

import com.createblock.mod.entity.ModEntities;
import com.createblock.mod.entity.boat.CreateblockBoat;
import com.createblock.mod.entity.boat.CreateblockChestBoat;
import com.createblock.mod.entity.client.CreateblockBoatRenderer;
import com.createblock.mod.entity.client.ModModelLayers;
import com.createblock.mod.entity.client.Shark;
import com.createblock.mod.entity.client.SharkRenderer;
import com.createblock.mod.fluid.ModFluidTypes;
import com.createblock.mod.fluid.ModFluids;
import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.init.ModCreativeTab;
import com.createblock.mod.init.ModItems;
import com.createblock.mod.init.ModLoot;
import com.createblock.mod.init.ModMachines;
import com.createblock.mod.init.ModRecipes;
import com.createblock.mod.init.ModStorage;
import com.createblock.mod.wood.ModWoodBlockEntities;
import com.createblock.mod.wood.ModWoodBlocks;
import com.createblock.mod.wood.ModWoodItems;
import com.createblock.mod.wood.ModWoodTypes;
import com.mojang.logging.LogUtils;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.blockentity.HangingSignRenderer;
import net.minecraft.client.renderer.blockentity.SignRenderer;
import net.minecraftforge.client.event.EntityRenderersEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.config.ModConfig;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;
import com.createblock.mod.entity.custom.SharkEntity;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import com.createblock.mod.sound.ModSounds;

/**
 * Createblock — custom resource line, alloys, machines, fluid, food,
 * and tiered storage crates for Create-based one-block modpacks.
 */
@Mod(Createblock.MODID)
public class Createblock {

    public static final String MODID = "createblock";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Createblock() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        // Blocks before items (items registers the block-items).
        ModFluidTypes.register(bus);
        ModFluids.register(bus);
        ModBlocks.register(bus);
        ModItems.register(bus);

        // CreateBlock underwater wood family (logs, wood, planks, signs, boats, ...).
        ModWoodTypes.init();
        ModWoodBlocks.register(bus);
        ModWoodItems.register(bus);
        ModWoodBlockEntities.register(bus);

        ModCreativeTab.register(bus);
        ModStorage.register(bus);
        ModLoot.register(bus);
        ModRecipes.register(bus);
        ModMachines.register(bus);
        ModSounds.SOUNDS.register(bus);

        // Entities
        ModEntities.register(bus);

        ModLoadingContext.get().registerConfig(
                ModConfig.Type.COMMON,
                Config.SPEC
        );

bus.addListener(this::clientSetup);
bus.addListener(this::registerEntityRenderers);
bus.addListener(this::registerLayerDefinitions);
bus.addListener(this::registerAttributes);

        LOGGER.info("[Createblock] initialised");
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> {

            MenuScreens.register(
                    ModStorage.CRATE_MENU.get(),
                    com.createblock.mod.storage.CrateScreen::new
            );

            MenuScreens.register(
                    ModStorage.CRATE_UPGRADE_MENU.get(),
                    com.createblock.mod.storage.CrateUpgradeScreen::new
            );

            MenuScreens.register(
                    ModMachines.GENERATOR_MENU.get(),
                    com.createblock.mod.machine.GeneratorScreen::new
            );

            MenuScreens.register(
                    ModMachines.PROCESSOR_MENU.get(),
                    com.createblock.mod.machine.ProcessorScreen::new
            );

            MenuScreens.register(
                    ModMachines.INFUSER_MENU.get(),
                    com.createblock.mod.machine.InfuserScreen::new
            );
        });
    }

/**
 * Registers entity renderers.
 */
private void registerEntityRenderers(
        final EntityRenderersEvent.RegisterRenderers event
) {
    event.registerEntityRenderer(
            ModEntities.SHARK.get(),
            SharkRenderer::new
    );

    event.registerEntityRenderer(
            ModEntities.CREATEBLOCK_BOAT.get(),
            context -> new CreateblockBoatRenderer(context, false)
    );
    event.registerEntityRenderer(
            ModEntities.CREATEBLOCK_CHEST_BOAT.get(),
            context -> new CreateblockBoatRenderer(context, true)
    );

    event.registerBlockEntityRenderer(
            ModWoodBlockEntities.CREATEBLOCK_SIGN.get(),
            SignRenderer::new
    );
    event.registerBlockEntityRenderer(
            ModWoodBlockEntities.CREATEBLOCK_HANGING_SIGN.get(),
            HangingSignRenderer::new
    );
}

/**
 * Registers entity model layers.
 */
private void registerLayerDefinitions(
        final EntityRenderersEvent.RegisterLayerDefinitions event
) {
    event.registerLayerDefinition(
            ModModelLayers.SHARK,
            Shark::createBodyLayer
    );
}

/**
 * Registers entity attributes.
 */
private void registerAttributes(
        final EntityAttributeCreationEvent event
) {
    event.put(
            ModEntities.SHARK.get(),
            SharkEntity.createAttributes().build()
    );
}
}