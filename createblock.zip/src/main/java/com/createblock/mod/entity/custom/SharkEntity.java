package com.createblock.mod.entity.custom;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.SmoothSwimmingLookControl;
import net.minecraft.world.entity.ai.control.SmoothSwimmingMoveControl;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.RandomSwimmingGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.animal.Dolphin;
import net.minecraft.world.entity.animal.Cod;
import net.minecraft.world.entity.animal.Pufferfish;
import net.minecraft.world.entity.animal.Salmon;
import net.minecraft.world.entity.animal.TropicalFish;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;

public class SharkEntity extends PathfinderMob {

    public SharkEntity(
            EntityType<? extends PathfinderMob> entityType,
            Level level
    ) {
        super(entityType, level);

        this.moveControl = new SmoothSwimmingMoveControl(
                this,
                85,
                10,
                0.02F,
                0.1F,
                true
        );

        this.lookControl = new SmoothSwimmingLookControl(
                this,
                10
        );
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Mob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 30.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.35D)
                .add(Attributes.ATTACK_DAMAGE, 6.0D)
                .add(Attributes.ATTACK_SPEED, 1.0D)
                .add(Attributes.FOLLOW_RANGE, 20.0D);
    }

    @Override
    protected void registerGoals() {

        // =========================
        // GOALS
        // =========================

        // Attack the current target
        this.goalSelector.addGoal(
                1,
                new MeleeAttackGoal(
                        this,
                        1.2D,
                        true
                )
        );

        // Swim around when not attacking
        this.goalSelector.addGoal(
                2,
                new RandomSwimmingGoal(
                        this,
                        1.0D,
                        40
                )
        );

        // Look at nearby players
        this.goalSelector.addGoal(
                3,
                new LookAtPlayerGoal(
                        this,
                        Player.class,
                        8.0F
                )
        );

        // Randomly look around
        this.goalSelector.addGoal(
                4,
                new RandomLookAroundGoal(this)
        );

        // =========================
        // TARGETS
        // =========================

        // Attack whatever hurts the shark
        this.targetSelector.addGoal(
                1,
                new HurtByTargetGoal(this)
        );

        // Attack players
        this.targetSelector.addGoal(
                2,
                new NearestAttackableTargetGoal<>(
                        this,
                        Player.class,
                        true
                )
        );

        // Attack dolphins
        this.targetSelector.addGoal(
                3,
                new NearestAttackableTargetGoal<>(
                        this,
                        Dolphin.class,
                        true
                )
        );

        // Attack cod
        this.targetSelector.addGoal(
                4,
                new NearestAttackableTargetGoal<>(
                        this,
                        Cod.class,
                        true
                )
        );

        // Attack salmon
        this.targetSelector.addGoal(
                5,
                new NearestAttackableTargetGoal<>(
                        this,
                        Salmon.class,
                        true
                )
        );

        // Attack tropical fish
        this.targetSelector.addGoal(
                6,
                new NearestAttackableTargetGoal<>(
                        this,
                        TropicalFish.class,
                        true
                )
        );

        // Attack pufferfish
        this.targetSelector.addGoal(
                7,
                new NearestAttackableTargetGoal<>(
                        this,
                        Pufferfish.class,
                        true
                )
        );
    }

    protected boolean canFloat() {
        return true;
    }
}