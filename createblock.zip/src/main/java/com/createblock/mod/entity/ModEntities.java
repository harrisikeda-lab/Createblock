package com.createblock.mod.entity;

import com.createblock.mod.Createblock;
import com.createblock.mod.entity.boat.CreateblockBoat;
import com.createblock.mod.entity.boat.CreateblockChestBoat;
import com.createblock.mod.entity.custom.SharkEntity;

import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModEntities {

    public static final DeferredRegister<EntityType<?>> ENTITY_TYPES =
            DeferredRegister.create(
                    ForgeRegistries.ENTITY_TYPES,
                    Createblock.MODID
            );

    public static final RegistryObject<EntityType<SharkEntity>> SHARK =
            ENTITY_TYPES.register(
                    "shark",
                    () -> EntityType.Builder.of(
                            SharkEntity::new,
                            MobCategory.WATER_CREATURE
                    )
                    .sized(1.4F, 0.8F)
                    .build("shark")
            );

    public static final RegistryObject<EntityType<CreateblockBoat>> CREATEBLOCK_BOAT =
            ENTITY_TYPES.register(
                    "createblock_boat",
                    () -> EntityType.Builder.<CreateblockBoat>of(CreateblockBoat::new, MobCategory.MISC)
                            .noSave()
                            .sized(1.375F, 0.5625F)
                            .clientTrackingRange(10)
                            .build("createblock_boat")
            );

    public static final RegistryObject<EntityType<CreateblockChestBoat>> CREATEBLOCK_CHEST_BOAT =
            ENTITY_TYPES.register(
                    "createblock_chest_boat",
                    () -> EntityType.Builder.<CreateblockChestBoat>of(CreateblockChestBoat::new, MobCategory.MISC)
                            .noSave()
                            .sized(1.375F, 0.5625F)
                            .clientTrackingRange(10)
                            .build("createblock_chest_boat")
            );

    public static void register(IEventBus eventBus) {
        ENTITY_TYPES.register(eventBus);
    }
}