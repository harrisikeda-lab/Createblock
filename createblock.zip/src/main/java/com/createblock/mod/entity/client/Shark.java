package com.createblock.mod.entity.client;

import com.createblock.mod.entity.custom.SharkEntity;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;

import net.minecraft.client.model.EntityModel;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.CubeDeformation;
import net.minecraft.client.model.geom.builders.CubeListBuilder;
import net.minecraft.client.model.geom.builders.LayerDefinition;
import net.minecraft.client.model.geom.builders.MeshDefinition;
import net.minecraft.client.model.geom.builders.PartDefinition;

public class Shark<T extends SharkEntity> extends EntityModel<T> {

    private final ModelPart root;
    private final ModelPart belly;
    private final ModelPart Fins;
    private final ModelPart nose;
    private final ModelPart mouth;
    private final ModelPart dorsal_fin;
    private final ModelPart left_pectoral_tip;
    private final ModelPart right_pectoral_fin;

    public Shark(ModelPart root) {
        this.root = root;

        this.belly = root.getChild("belly");
        this.Fins = root.getChild("Fins");
        this.nose = root.getChild("nose");
        this.mouth = this.nose.getChild("mouth");
        this.dorsal_fin = root.getChild("dorsal_fin");
        this.left_pectoral_tip = root.getChild("left_pectoral_tip");
        this.right_pectoral_fin = root.getChild("right_pectoral_fin");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition meshdefinition = new MeshDefinition();
        PartDefinition partdefinition = meshdefinition.getRoot();

        PartDefinition belly = partdefinition.addOrReplaceChild(
                "belly",
                CubeListBuilder.create(),
                PartPose.offset(0.0F, 24.0F, 0.0F)
        );

        PartDefinition belly_r1 = belly.addOrReplaceChild(
                "belly_r1",
                CubeListBuilder.create()
                        .texOffs(36, 34)
                        .addBox(
                                -4.0F, -5.5F, -5.0F,
                                8.0F, 1.5F, 10.0F,
                                new CubeDeformation(0.0F)
                        )
                        .texOffs(0, 21)
                        .addBox(
                                -4.0F, 3.0F, -5.0F,
                                8.0F, 2.0F, 11.0F,
                                new CubeDeformation(0.0F)
                        )
                        .texOffs(0, 0)
                        .addBox(
                                -5.0F, -4.0F, -7.0F,
                                10.0F, 7.0F, 14.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 0.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        PartDefinition Fins = partdefinition.addOrReplaceChild(
                "Fins",
                CubeListBuilder.create(),
                PartPose.offset(-4.0F, 23.0F, -2.0F)
        );

        Fins.addOrReplaceChild(
                "tail_fin_lower_tip_r1",
                CubeListBuilder.create()
                        .texOffs(52, 65)
                        .addBox(
                                -1.0F, -3.0F, 0.0F,
                                2.0F, 3.0F, 2.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, -4.0F, 21.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        Fins.addOrReplaceChild(
                "tail_fin_lower_r1",
                CubeListBuilder.create()
                        .texOffs(38, 64)
                        .addBox(
                                -1.5F, -6.0F, 0.0F,
                                3.0F, 6.0F, 4.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, 1.0F, 19.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        Fins.addOrReplaceChild(
                "tail_fin_upper_tip_r1",
                CubeListBuilder.create()
                        .texOffs(28, 49)
                        .addBox(
                                -1.0F, 0.0F, 0.0F,
                                2.0F, 4.0F, 2.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, 8.0F, 21.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        Fins.addOrReplaceChild(
                "tail_fin_upper_r1",
                CubeListBuilder.create()
                        .texOffs(62, 46)
                        .addBox(
                                -1.5F, 0.0F, 0.0F,
                                3.0F, 6.5F, 4.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, 2.5F, 19.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        Fins.addOrReplaceChild(
                "tail_r1",
                CubeListBuilder.create()
                        .texOffs(58, 57)
                        .addBox(
                                -2.0F, -1.5F, 0.0F,
                                4.0F, 3.0F, 5.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, 1.0F, 17.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        Fins.addOrReplaceChild(
                "tail_stalk_r1",
                CubeListBuilder.create()
                        .texOffs(0, 56)
                        .addBox(
                                -2.5F, -2.0F, -1.0F,
                                5.0F, 4.0F, 6.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, 1.0F, 14.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        Fins.addOrReplaceChild(
                "tail_base_r1",
                CubeListBuilder.create()
                        .texOffs(36, 46)
                        .addBox(
                                -3.5F, -2.5F, -1.0F,
                                7.0F, 5.0F, 6.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        4.0F, 1.0F, 9.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        PartDefinition nose = partdefinition.addOrReplaceChild(
                "nose",
                CubeListBuilder.create(),
                PartPose.offset(0.0F, 24.0F, -18.0F)
        );

        nose.addOrReplaceChild(
                "nose_r1",
                CubeListBuilder.create()
                        .texOffs(38, 57)
                        .addBox(
                                -3.5F, -2.0F, -2.0F,
                                7.0F, 4.0F, 3.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 0.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        nose.addOrReplaceChild(
                "head_r1",
                CubeListBuilder.create()
                        .texOffs(0, 34)
                        .addBox(
                                -5.5F, -4.0F, -5.0F,
                                11.0F, 8.0F, 7.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 11.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        nose.addOrReplaceChild(
                "snout_r1",
                CubeListBuilder.create()
                        .texOffs(38, 21)
                        .addBox(
                                -4.5F, -3.0F, -6.0F,
                                9.0F, 7.0F, 7.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 6.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        PartDefinition mouth = nose.addOrReplaceChild(
                "mouth",
                CubeListBuilder.create()
                        .texOffs(2, 1)
                        .addBox(-1.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(-2.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(-4.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(-3.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(0.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(1.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(2.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F)
                        .texOffs(2, 1)
                        .addBox(3.0F, -5.0F, -5.0F, 1.0F, 1.0F, 1.0F),
                PartPose.offset(0.0F, 4.0F, 6.0F)
        );

        mouth.addOrReplaceChild(
                "mouth_r1",
                CubeListBuilder.create()
                        .texOffs(48, 0)
                        .addBox(
                                -4.0F, -3.0F, -5.0F,
                                8.0F, 3.0F, 6.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, -4.0F, 0.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        PartDefinition dorsal_fin = partdefinition.addOrReplaceChild(
                "dorsal_fin",
                CubeListBuilder.create(),
                PartPose.offset(0.0F, 27.0F, 0.0F)
        );

        dorsal_fin.addOrReplaceChild(
                "dorsal_fin_r1",
                CubeListBuilder.create()
                        .texOffs(22, 57)
                        .addBox(
                                -1.5F, 0.0F, -1.0F,
                                3.0F, 7.0F, 5.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 0.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        dorsal_fin.addOrReplaceChild(
                "dorsal_tip_r1",
                CubeListBuilder.create()
                        .texOffs(62, 15)
                        .addBox(
                                -1.0F, 0.0F, -1.0F,
                                2.0F, 6.0F, 2.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, -7.0F, 2.0F,
                        0.5236F, 0.0F, -3.1416F
                )
        );

        PartDefinition left_pectoral_tip = partdefinition.addOrReplaceChild(
                "left_pectoral_tip",
                CubeListBuilder.create(),
                PartPose.offset(-10.0F, 23.0F, -1.0F)
        );

        left_pectoral_tip.addOrReplaceChild(
                "left_pectoral_tip_r1",
                CubeListBuilder.create()
                        .texOffs(48, 15)
                        .addBox(
                                -5.0F, -1.0F, -1.0F,
                                5.0F, 1.0F, 2.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 0.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        left_pectoral_tip.addOrReplaceChild(
                "left_pectoral_fin_r1",
                CubeListBuilder.create()
                        .texOffs(48, 8)
                        .addBox(
                                -8.0F, -1.0F, -2.0F,
                                8.0F, 1.0F, 6.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        6.0F, 0.0F, -1.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        PartDefinition right_pectoral_fin = partdefinition.addOrReplaceChild(
                "right_pectoral_fin",
                CubeListBuilder.create(),
                PartPose.offset(4.0F, 23.0F, -2.0F)
        );

        right_pectoral_fin.addOrReplaceChild(
                "right_pectoral_fin_r1",
                CubeListBuilder.create()
                        .texOffs(0, 49)
                        .addBox(
                                0.0F, -1.0F, -2.0F,
                                8.0F, 1.0F, 6.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        0.0F, 0.0F, 0.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        right_pectoral_fin.addOrReplaceChild(
                "right_pectoral_tip_r1",
                CubeListBuilder.create()
                        .texOffs(48, 18)
                        .addBox(
                                0.0F, -1.0F, -1.0F,
                                5.0F, 1.0F, 2.0F,
                                new CubeDeformation(0.0F)
                        ),
                PartPose.offsetAndRotation(
                        6.0F, 0.0F, 1.0F,
                        0.0F, 0.0F, -3.1416F
                )
        );

        return LayerDefinition.create(meshdefinition, 128, 128);
    }

    @Override
    public void setupAnim(
            SharkEntity entity,
            float limbSwing,
            float limbSwingAmount,
            float ageInTicks,
            float netHeadYaw,
            float headPitch
    ) {
        /*
         * Reset animation transforms.
         *
         * This is important because Minecraft reuses the model
         * and otherwise the rotations can accumulate.
         */
        Fins.yRot = 0.0F;
        left_pectoral_tip.zRot = 0.0F;
        right_pectoral_fin.zRot = 0.0F;
        mouth.xRot = 0.0F;

        /*
         * ==========================================
         * TAIL FIN SWIM
         * ==========================================
         *
         * Blockbench:
         *
         * math.sin(query.anim_time * 360) * 25
         *
         * query.anim_time is seconds.
         *
         * ageInTicks is Minecraft ticks.
         * 20 ticks = 1 second.
         */

        float swimTime = ageInTicks / 20.0F;

        float tailWave =
                (float) Math.sin(swimTime * Math.PI * 2.0F);

        /*
         * Tail movement.
         *
         * The tail swings from side to side.
         */
        Fins.yRot = tailWave * 0.44F;

        /*
         * Pectoral fins gently flap while swimming.
         */
        float finWave =
                (float) Math.sin(swimTime * Math.PI * 2.0F);

        left_pectoral_tip.zRot =
                finWave * 0.105F;

        right_pectoral_fin.zRot =
                -finWave * 0.105F;

        /*
         * ==========================================
         * ATTACK ANIMATION
         * ==========================================
         *
         * Your Blockbench animation is:
         *
         * 0 sec   = 0 degrees
         * 0.25 sec = 60 degrees
         * 0.5 sec = 0 degrees
         */

        if (entity.swinging) {
            float attackProgress =
                    entity.getAttackAnim(ageInTicks - entity.tickCount);

            /*
             * Swing animation goes:
             *
             * 0 -> 1 -> 0
             *
             * Convert that into a mouth opening.
             */
            float mouthOpen =
                    (float) Math.sin(attackProgress * Math.PI);

            mouth.xRot =
                    mouthOpen * (float) Math.toRadians(60.0F);
        }
    }

    @Override
    public void renderToBuffer(
            PoseStack poseStack,
            VertexConsumer vertexConsumer,
            int packedLight,
            int packedOverlay,
            float red,
            float green,
            float blue,
            float alpha
    ) {
        root.render(
                poseStack,
                vertexConsumer,
                packedLight,
                packedOverlay,
                red,
                green,
                blue,
                alpha
        );
    }

    @Override
    public ModelPart root() {
        return root;
    }
}