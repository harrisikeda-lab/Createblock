package com.createblock.mod.entity.boat;

import com.createblock.mod.entity.ModEntities;
import com.createblock.mod.wood.ModWoodItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** The CreateBlock boat. Only its drop item and rendering differ from vanilla boats. */
public class CreateblockBoat extends Boat {

    public CreateblockBoat(EntityType<? extends Boat> type, Level level) {
        super(type, level);
    }

    public CreateblockBoat(Level level, double x, double y, double z) {
        this(ModEntities.CREATEBLOCK_BOAT.get(), level);
        this.setPos(x, y, z);
        this.xo = x;
        this.yo = y;
        this.zo = z;
    }

    @Override
    public Item getDropItem() {
        return ModWoodItems.CREATEBLOCK_BOAT_ITEM.get();
    }
}
