package com.createblock.mod.entity.boat;

import net.minecraft.core.BlockPos;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntitySelector;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;

import java.util.List;
import java.util.function.BiFunction;

/**
 * A pure Forge-1.20.1 boat item. Vanilla {@code BoatItem} is hard-wired to the closed
 * {@code Boat.Type} enum, so CreateBlock uses its own item that spawns the CreateBlock
 * boat/chest-boat entity directly instead of relying on that enum.
 */
public class CreateblockBoatItem extends Item {

    private final BiFunction<Level, Vec3, ? extends Boat> boatFactory;

    public CreateblockBoatItem(boolean hasChest, Properties properties) {
        super(properties);
        this.boatFactory = hasChest
                ? (level, pos) -> new CreateblockChestBoat(level, pos.x, pos.y, pos.z)
                : (level, pos) -> new CreateblockBoat(level, pos.x, pos.y, pos.z);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);
        HitResult hitresult = getPlayerPOVHitResult(level, player, ClipContext.Fluid.ANY);
        if (hitresult.getType() == HitResult.Type.MISS) {
            return InteractionResultHolder.pass(itemstack);
        }

        Vec3 viewVector = player.getViewVector(1.0F);
        List<Entity> nearby = level.getEntities(player,
                player.getBoundingBox().expandTowards(viewVector.scale(5.0D)).inflate(1.0D),
                EntitySelector.NO_SPECTATORS.and(Entity::isPickable));
        if (!nearby.isEmpty()) {
            Vec3 eyePos = player.getEyePosition();
            for (Entity entity : nearby) {
                AABB aabb = entity.getBoundingBox().inflate(entity.getPickRadius());
                if (aabb.contains(eyePos)) {
                    return InteractionResultHolder.pass(itemstack);
                }
            }
        }

        if (hitresult.getType() != HitResult.Type.BLOCK) {
            return InteractionResultHolder.pass(itemstack);
        }

        Vec3 hitPos = hitresult.getLocation();
        Boat boat = this.boatFactory.apply(level, new Vec3(hitPos.x, hitPos.y, hitPos.z));
        boat.setYRot(player.getYRot());

        BlockPos below = BlockPos.containing(hitPos);
        double liftAboveGround = level.getFluidState(below).isEmpty() ? (double) boat.getBbHeight() / 2.0D : 0.0D;
        boat.setPos(hitPos.x, hitPos.y + liftAboveGround, hitPos.z);

        if (!level.noCollision(boat, boat.getBoundingBox())) {
            return InteractionResultHolder.fail(itemstack);
        }

        if (!level.isClientSide) {
            level.addFreshEntity(boat);
            level.gameEvent(player, GameEvent.ENTITY_PLACE, hitPos);
            if (!player.getAbilities().instabuild) {
                itemstack.shrink(1);
            }
        }
        player.awardStat(Stats.ITEM_USED.get(this));
        return InteractionResultHolder.sidedSuccess(itemstack, level.isClientSide());
    }
}
