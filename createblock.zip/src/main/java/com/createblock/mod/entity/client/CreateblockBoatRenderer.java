package com.createblock.mod.entity.client;

import com.createblock.mod.Createblock;
import com.mojang.datafixers.util.Pair;
import net.minecraft.client.model.ListModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.BoatRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.BoatModel;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.vehicle.Boat;

/**
 * Renders the CreateBlock boat/chest boat. Vanilla {@link BoatRenderer} resolves its
 * texture from the closed {@code Boat.Type} enum, which CreateBlock cannot join, so this
 * overrides the model/texture lookup to always return the CreateBlock model+texture pair.
 */
public class CreateblockBoatRenderer extends BoatRenderer {

    private final Pair<ResourceLocation, ListModel<Boat>> modelWithLocation;

    public CreateblockBoatRenderer(EntityRendererProvider.Context context, boolean chestBoat) {
        super(context, chestBoat);
        ResourceLocation texture = new ResourceLocation(Createblock.MODID,
                chestBoat ? "textures/entity/chest_boat/createblock.png" : "textures/entity/boat/createblock.png");
        ListModel<Boat> model = new BoatModel(
                context.bakeLayer(chestBoat ? ModelLayers.CHEST_BOAT : ModelLayers.BOAT), chestBoat);
        this.modelWithLocation = Pair.of(texture, model);
    }

    @Override
    public Pair<ResourceLocation, ListModel<Boat>> getModelWithLocation(Boat boat) {
        return this.modelWithLocation;
    }
}
