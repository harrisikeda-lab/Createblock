package com.createblock.mod.entity.boat;

import com.createblock.mod.entity.ModEntities;
import com.createblock.mod.wood.ModWoodItems;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.vehicle.Boat;
import net.minecraft.world.entity.vehicle.ChestBoat;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/** The CreateBlock chest boat. Adds inventory to the CreateBlock boat. */
public class CreateblockChestBoat extends ChestBoat {

    public CreateblockChestBoat(EntityType<? extends Boat> type, Level level) {
        super(type, level);
    }

    public CreateblockChestBoat(Level level, double x, double y, double z) {
        this(ModEntities.CREATEBLOCK_CHEST_BOAT.get(), level);
        this.setPos(x, y, z);
        this.xo = x;
        this.yo = y;
        this.zo = z;
    }

    @Override
    public Item getDropItem() {
        return ModWoodItems.CREATEBLOCK_CHEST_BOAT_ITEM.get();
    }
}
