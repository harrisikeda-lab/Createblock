package com.createblock.mod.entity.client;

import com.createblock.mod.Createblock;
import com.createblock.mod.entity.custom.SharkEntity;

import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class SharkRenderer extends MobRenderer<SharkEntity, Shark<SharkEntity>> {

    private static final ResourceLocation SHARK_TEXTURE =
            new ResourceLocation(Createblock.MODID, "textures/entity/shark.png");

    public SharkRenderer(EntityRendererProvider.Context context) {
        super(
                context,
                new Shark<>(context.bakeLayer(ModModelLayers.SHARK)),
                0.5F
        );
    }

    @Override
    public ResourceLocation getTextureLocation(SharkEntity entity) {
        return SHARK_TEXTURE;
    }
}