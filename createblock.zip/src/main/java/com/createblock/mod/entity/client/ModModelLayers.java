package com.createblock.mod.entity.client;

import com.createblock.mod.Createblock;

import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.resources.ResourceLocation;

public class ModModelLayers {

    public static final ModelLayerLocation SHARK =
            new ModelLayerLocation(
                    new ResourceLocation(Createblock.MODID, "shark"),
                    "main"
            );
}