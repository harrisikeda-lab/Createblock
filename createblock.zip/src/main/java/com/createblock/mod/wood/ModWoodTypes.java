package com.createblock.mod.wood;

import com.createblock.mod.Createblock;
import net.minecraft.world.level.block.state.properties.BlockSetType;
import net.minecraft.world.level.block.state.properties.WoodType;

/** Registers the BlockSetType/WoodType used by CreateBlock doors, trapdoors and signs. */
public class ModWoodTypes {

    public static final BlockSetType CREATEBLOCK_SET =
            BlockSetType.register(new BlockSetType(Createblock.MODID + ":createblock_logs"));

    public static final WoodType CREATEBLOCK_WOOD_TYPE =
            WoodType.register(new WoodType(Createblock.MODID + ":createblock_logs", CREATEBLOCK_SET));

    public static void init() {
        // no-op, forces class load so BlockSetType/WoodType statics register early
    }
}
