package com.createblock.mod.wood;

import com.createblock.mod.Createblock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.ButtonBlock;
import net.minecraft.world.level.block.CeilingHangingSignBlock;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.FenceBlock;
import net.minecraft.world.level.block.FenceGateBlock;
import net.minecraft.world.level.block.PressurePlateBlock;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.SlabBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.StandingSignBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.WallBlock;
import net.minecraft.world.level.block.WallHangingSignBlock;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The CreateBlock underwater wood family: logs, wood, planks and every wooden building block. */
public class ModWoodBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Createblock.MODID);

    private static BlockBehaviour.Properties logProperties() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.WOOD)
                .strength(2.0F)
                .sound(SoundType.WOOD)
                .ignitedByLava();
    }

    private static BlockBehaviour.Properties plankProperties() {
        return BlockBehaviour.Properties.of()
                .mapColor(MapColor.WOOD)
                .strength(2.0F, 3.0F)
                .sound(SoundType.WOOD)
                .ignitedByLava();
    }

    // ---- Logs & wood ----
    public static final RegistryObject<Block> STRIPPED_CREATEBLOCK_LOG = BLOCKS.register("stripped_createblock_log",
            () -> new RotatedPillarBlock(logProperties()));

    public static final RegistryObject<Block> CREATEBLOCK_LOG = BLOCKS.register("createblock_log",
            () -> new CreateblockLogBlock(logProperties().mapColor(state ->
                    state.getValue(RotatedPillarBlock.AXIS) == net.minecraft.core.Direction.Axis.Y
                            ? MapColor.PODZOL : MapColor.WOOD), STRIPPED_CREATEBLOCK_LOG));

    public static final RegistryObject<Block> STRIPPED_CREATEBLOCK_WOOD = BLOCKS.register("stripped_createblock_wood",
            () -> new RotatedPillarBlock(logProperties()));

    public static final RegistryObject<Block> CREATEBLOCK_WOOD = BLOCKS.register("createblock_wood",
            () -> new CreateblockLogBlock(logProperties(), STRIPPED_CREATEBLOCK_WOOD));

    // ---- Planks ----
    public static final RegistryObject<Block> CREATEBLOCK_PLANKS = BLOCKS.register("createblock_planks",
            () -> new Block(plankProperties()));

    // ---- Stairs & slab ----
    public static final RegistryObject<Block> CREATEBLOCK_STAIRS = BLOCKS.register("createblock_stairs",
            () -> new StairBlock(() -> CREATEBLOCK_PLANKS.get().defaultBlockState(), plankProperties()));

    public static final RegistryObject<Block> CREATEBLOCK_SLAB = BLOCKS.register("createblock_slab",
            () -> new SlabBlock(plankProperties()));

    // ---- Fence & fence gate ----
    public static final RegistryObject<Block> CREATEBLOCK_FENCE = BLOCKS.register("createblock_fence",
            () -> new FenceBlock(plankProperties()));

    public static final RegistryObject<Block> CREATEBLOCK_FENCE_GATE = BLOCKS.register("createblock_fence_gate",
            () -> new FenceGateBlock(plankProperties(), ModWoodTypes.CREATEBLOCK_WOOD_TYPE));

    // ---- Door & trapdoor ----
    public static final RegistryObject<Block> CREATEBLOCK_DOOR = BLOCKS.register("createblock_door",
            () -> new DoorBlock(plankProperties().strength(3.0F).noOcclusion(), ModWoodTypes.CREATEBLOCK_SET));

    public static final RegistryObject<Block> CREATEBLOCK_TRAPDOOR = BLOCKS.register("createblock_trapdoor",
            () -> new TrapDoorBlock(plankProperties().noOcclusion().isValidSpawn((state, level, pos, entityType) -> false),
                    ModWoodTypes.CREATEBLOCK_SET));

    // ---- Pressure plate & button ----
    public static final RegistryObject<Block> CREATEBLOCK_PRESSURE_PLATE = BLOCKS.register("createblock_pressure_plate",
            () -> new PressurePlateBlock(PressurePlateBlock.Sensitivity.EVERYTHING,
                    plankProperties().noCollission().strength(0.5F), ModWoodTypes.CREATEBLOCK_SET));

    public static final RegistryObject<Block> CREATEBLOCK_BUTTON = BLOCKS.register("createblock_button",
            () -> new ButtonBlock(plankProperties().noCollission().strength(0.5F),
                    ModWoodTypes.CREATEBLOCK_SET, 30, true));

    // ---- Wall ----
    public static final RegistryObject<Block> CREATEBLOCK_WALL = BLOCKS.register("createblock_wall",
            () -> new WallBlock(BlockBehaviour.Properties.copy(Blocks.COBBLESTONE_WALL)
                    .mapColor(MapColor.WOOD).sound(SoundType.WOOD).strength(2.0F, 3.0F).ignitedByLava()));

    // ---- Signs ----
    public static final RegistryObject<Block> CREATEBLOCK_SIGN = BLOCKS.register("createblock_sign",
            () -> new StandingSignBlock(plankProperties().noCollission().strength(1.0F).noOcclusion(),
                    ModWoodTypes.CREATEBLOCK_WOOD_TYPE));

    public static final RegistryObject<Block> CREATEBLOCK_WALL_SIGN = BLOCKS.register("createblock_wall_sign",
            () -> new WallSignBlock(plankProperties().noCollission().strength(1.0F).noOcclusion()
                            .lootFrom(CREATEBLOCK_SIGN::get),
                    ModWoodTypes.CREATEBLOCK_WOOD_TYPE));

    // ---- Hanging signs ----
    public static final RegistryObject<Block> CREATEBLOCK_HANGING_SIGN = BLOCKS.register("createblock_hanging_sign",
            () -> new CeilingHangingSignBlock(plankProperties().noCollission().strength(1.0F).noOcclusion(),
                    ModWoodTypes.CREATEBLOCK_WOOD_TYPE));

    public static final RegistryObject<Block> CREATEBLOCK_WALL_HANGING_SIGN = BLOCKS.register("createblock_wall_hanging_sign",
            () -> new WallHangingSignBlock(plankProperties().noCollission().strength(1.0F).noOcclusion()
                            .lootFrom(CREATEBLOCK_HANGING_SIGN::get),
                    ModWoodTypes.CREATEBLOCK_WOOD_TYPE));

    // ---- Sapling & leaves ----
    public static final RegistryObject<Block> CREATEBLOCK_SAPLING = BLOCKS.register("createblock_sapling",
            () -> new CreateblockSaplingBlock(ModTrees.CREATEBLOCK_TREE_GROWER,
                    BlockBehaviour.Properties.of()
                            .mapColor(MapColor.PLANT)
                            .noCollission()
                            .randomTicks()
                            .instabreak()
                            .sound(SoundType.GRASS)
                            .pushReaction(PushReaction.DESTROY)));

    public static final RegistryObject<Block> CREATEBLOCK_LEAVES = BLOCKS.register("createblock_leaves",
            () -> new CreateblockLeavesBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.PLANT)
                    .strength(0.2F)
                    .randomTicks()
                    .sound(SoundType.GRASS)
                    .noOcclusion()
                    .isValidSpawn((state, level, pos, type) -> false)
                    .isSuffocating((state, level, pos) -> false)
                    .isViewBlocking((state, level, pos) -> false)
                    .ignitedByLava()
                    .pushReaction(PushReaction.DESTROY)));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }
}
