package com.createblock.mod.wood;

import com.createblock.mod.Createblock;
import com.createblock.mod.entity.boat.CreateblockBoatItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.HangingSignItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.SignItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Block-items for the CreateBlock wood family, plus the boat/chest-boat/sapling/leaves items. */
public class ModWoodItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Createblock.MODID);

    public static final RegistryObject<Item> CREATEBLOCK_LOG = ITEMS.register("createblock_log",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_LOG.get(), new Item.Properties()));
    public static final RegistryObject<Item> STRIPPED_CREATEBLOCK_LOG = ITEMS.register("stripped_createblock_log",
            () -> new BlockItem(ModWoodBlocks.STRIPPED_CREATEBLOCK_LOG.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_WOOD = ITEMS.register("createblock_wood",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_WOOD.get(), new Item.Properties()));
    public static final RegistryObject<Item> STRIPPED_CREATEBLOCK_WOOD = ITEMS.register("stripped_createblock_wood",
            () -> new BlockItem(ModWoodBlocks.STRIPPED_CREATEBLOCK_WOOD.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_PLANKS = ITEMS.register("createblock_planks",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_PLANKS.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_STAIRS = ITEMS.register("createblock_stairs",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_STAIRS.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_SLAB = ITEMS.register("createblock_slab",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_SLAB.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_FENCE = ITEMS.register("createblock_fence",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_FENCE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_FENCE_GATE = ITEMS.register("createblock_fence_gate",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_FENCE_GATE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_DOOR = ITEMS.register("createblock_door",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_DOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_TRAPDOOR = ITEMS.register("createblock_trapdoor",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_TRAPDOOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_PRESSURE_PLATE = ITEMS.register("createblock_pressure_plate",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_PRESSURE_PLATE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_BUTTON = ITEMS.register("createblock_button",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_BUTTON.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_WALL = ITEMS.register("createblock_wall",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_WALL.get(), new Item.Properties()));

    public static final RegistryObject<Item> CREATEBLOCK_SAPLING = ITEMS.register("createblock_sapling",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_SAPLING.get(), new Item.Properties()));
    public static final RegistryObject<Item> CREATEBLOCK_LEAVES = ITEMS.register("createblock_leaves",
            () -> new BlockItem(ModWoodBlocks.CREATEBLOCK_LEAVES.get(), new Item.Properties()));

    public static final RegistryObject<Item> CREATEBLOCK_SIGN = ITEMS.register("createblock_sign",
            () -> new SignItem(new Item.Properties(), ModWoodBlocks.CREATEBLOCK_SIGN.get(), ModWoodBlocks.CREATEBLOCK_WALL_SIGN.get()));
    public static final RegistryObject<Item> CREATEBLOCK_HANGING_SIGN = ITEMS.register("createblock_hanging_sign",
            () -> new HangingSignItem(ModWoodBlocks.CREATEBLOCK_HANGING_SIGN.get(), ModWoodBlocks.CREATEBLOCK_WALL_HANGING_SIGN.get(), new Item.Properties()));

    public static final RegistryObject<Item> CREATEBLOCK_BOAT_ITEM = ITEMS.register("createblock_boat",
            () -> new CreateblockBoatItem(false, new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> CREATEBLOCK_CHEST_BOAT_ITEM = ITEMS.register("createblock_chest_boat",
            () -> new CreateblockBoatItem(true, new Item.Properties().stacksTo(1)));

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
