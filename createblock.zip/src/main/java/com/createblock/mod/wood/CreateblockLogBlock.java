package com.createblock.mod.wood;

import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.RotatedPillarBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ToolActions;

import java.util.function.Supplier;

/**
 * A log/wood block that strips into another CreateBlock block via the Forge
 * {@code AXE_STRIP} tool action, instead of relying on a custom axe item.
 */
public class CreateblockLogBlock extends RotatedPillarBlock {

    private final Supplier<net.minecraft.world.level.block.Block> stripped;

    public CreateblockLogBlock(Properties properties, Supplier<net.minecraft.world.level.block.Block> stripped) {
        super(properties);
        this.stripped = stripped;
    }

    @Override
    public BlockState getToolModifiedState(BlockState state, UseOnContext context, net.minecraftforge.common.ToolAction toolAction, boolean simulate) {
        if (toolAction == ToolActions.AXE_STRIP && this.stripped != null) {
            return this.stripped.get().defaultBlockState().setValue(AXIS, state.getValue(AXIS));
        }
        return super.getToolModifiedState(state, context, toolAction, simulate);
    }
}
