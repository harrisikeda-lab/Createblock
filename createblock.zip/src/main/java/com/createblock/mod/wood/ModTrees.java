package com.createblock.mod.wood;

import com.createblock.mod.Createblock;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.block.grower.AbstractTreeGrower;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;

import javax.annotation.Nullable;

/** Resource key and {@link AbstractTreeGrower} for the CreateBlock underwater tree. */
public class ModTrees {

    public static final ResourceKey<ConfiguredFeature<?, ?>> CREATEBLOCK_TREE = ResourceKey.create(
            Registries.CONFIGURED_FEATURE,
            new ResourceLocation(Createblock.MODID, "createblock_tree"));

    public static final AbstractTreeGrower CREATEBLOCK_TREE_GROWER = new AbstractTreeGrower() {
        @Nullable
        @Override
        protected ResourceKey<ConfiguredFeature<?, ?>> getConfiguredFeature(RandomSource random, boolean bees) {
            return CREATEBLOCK_TREE;
        }
    };
}
