package com.createblock.mod.wood;

import com.createblock.mod.Createblock;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.grower.TreeGrower;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;

import java.util.Optional;

/** Resource keys and the {@link TreeGrower} for the CreateBlock underwater tree. */
public class ModTrees {

    public static final ResourceKey<ConfiguredFeature<?, ?>> CREATEBLOCK_TREE = ResourceKey.create(
            Registries.CONFIGURED_FEATURE,
            new ResourceLocation(Createblock.MODID, "createblock_tree"));

    public static final TreeGrower CREATEBLOCK_TREE_GROWER = new TreeGrower(
            "createblock",
            Optional.empty(),
            Optional.of(CREATEBLOCK_TREE),
            Optional.empty());
}
