package com.createblock.mod.wood;

import com.createblock.mod.Createblock;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.entity.HangingSignBlockEntity;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * Block entity types for the CreateBlock signs. Vanilla's own SIGN/HANGING_SIGN
 * BlockEntityType instances are only valid for vanilla wood blocks, so CreateBlock
 * registers its own BlockEntityType wrapping the same vanilla block entity classes,
 * valid for the CreateBlock sign blocks.
 */
public class ModWoodBlockEntities {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Createblock.MODID);

    public static final RegistryObject<BlockEntityType<SignBlockEntity>> CREATEBLOCK_SIGN =
            BLOCK_ENTITIES.register("createblock_sign", () -> BlockEntityType.Builder.of(
                    SignBlockEntity::new,
                    ModWoodBlocks.CREATEBLOCK_SIGN.get(),
                    ModWoodBlocks.CREATEBLOCK_WALL_SIGN.get()
            ).build(null));

    public static final RegistryObject<BlockEntityType<HangingSignBlockEntity>> CREATEBLOCK_HANGING_SIGN =
            BLOCK_ENTITIES.register("createblock_hanging_sign", () -> BlockEntityType.Builder.of(
                    HangingSignBlockEntity::new,
                    ModWoodBlocks.CREATEBLOCK_HANGING_SIGN.get(),
                    ModWoodBlocks.CREATEBLOCK_WALL_HANGING_SIGN.get()
            ).build(null));

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
    }
}
