package com.createblock.mod.sound;

import com.createblock.mod.Createblock;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvent;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public class ModSounds {

    public static final DeferredRegister<SoundEvent> SOUNDS =
            DeferredRegister.create(Registries.SOUND_EVENT, Createblock.MODID);

    public static final RegistryObject<SoundEvent> HELLDIVERS_RAISE_FLAG =
            SOUNDS.register("helldivers_raise_flag",
                    () -> SoundEvent.createVariableRangeEvent(
                            new ResourceLocation(
                                    Createblock.MODID,
                                    "helldivers_raise_flag"
                            )
                    ));
}