package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.fluid.ModFluids;
import com.createblock.mod.item.ModTiers;
import com.createblock.mod.item.PaxelItem;
import com.createblock.mod.item.StewItem;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.BucketItem;
import net.minecraft.world.item.HoeItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemNameBlockItem;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.PickaxeItem;
import net.minecraft.world.item.ShovelItem;
import net.minecraft.world.item.SwordItem;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import com.createblock.mod.sound.ModSounds;
import net.minecraft.world.item.RecordItem;

/** All Createblock items, including the block-items for ModBlocks. */
public class ModItems {

    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Createblock.MODID);

    // ================= FOOD PROPERTIES =================
    public static final FoodProperties ENERGY_BAR_FOOD = new FoodProperties.Builder()
            .nutrition(6).saturationMod(3.0F).fast()
            .effect(() -> new MobEffectInstance(MobEffects.MOVEMENT_SPEED, 20 * 20, 0), 1.0F)
            .build();

    public static final FoodProperties GOLDEN_SNACK_FOOD = new FoodProperties.Builder()
            .nutrition(8).saturationMod(1.2F).alwaysEat()
            .effect(() -> new MobEffectInstance(MobEffects.ABSORPTION, 60 * 20, 0), 1.0F)
            .effect(() -> new MobEffectInstance(MobEffects.REGENERATION, 5 * 20, 1), 1.0F)
            .build();

    public static final FoodProperties STEW_FOOD = new FoodProperties.Builder()
            .nutrition(8).saturationMod(2.0F)
            .effect(() -> new MobEffectInstance(MobEffects.SATURATION, 5 * 20, 0), 1.0F)
            .build();

    public static final FoodProperties SANDWICH_FOOD = new FoodProperties.Builder()
            .nutrition(7).saturationMod(1.0F).fast().build();

    public static final FoodProperties BERRY_FOOD = new FoodProperties.Builder()
            .nutrition(2).saturationMod(0.2F).fast().build();

    // ================= RESOURCE ITEMS =================
    public static final RegistryObject<Item> RAW_ORE = ITEMS.register("raw_ore", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> INGOT = ITEMS.register("ingot", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> NUGGET = ITEMS.register("nugget", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> DUST = ITEMS.register("dust", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> PLATE = ITEMS.register("plate", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> GEM = ITEMS.register("gem", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ALLOY_INGOT = ITEMS.register("alloy_ingot", () -> new Item(new Item.Properties()));
    public static final RegistryObject<Item> ALLOY_NUGGET = ITEMS.register("alloy_nugget", () -> new Item(new Item.Properties()));

    // ================= FOOD ITEMS =================
    public static final RegistryObject<Item> ENERGY_BAR = ITEMS.register("energy_bar",
            () -> new Item(new Item.Properties().food(ENERGY_BAR_FOOD)));
    public static final RegistryObject<Item> GOLDEN_SNACK = ITEMS.register("golden_snack",
            () -> new Item(new Item.Properties().food(GOLDEN_SNACK_FOOD).rarity(net.minecraft.world.item.Rarity.EPIC)));
    public static final RegistryObject<Item> STEW = ITEMS.register("stew",
            () -> new StewItem(new Item.Properties().food(STEW_FOOD).stacksTo(1)));
    public static final RegistryObject<Item> SANDWICH = ITEMS.register("sandwich",
            () -> new Item(new Item.Properties().food(SANDWICH_FOOD)));

    // ================= BLOCK ITEMS =================
    public static final RegistryObject<Item> BLOCK_ITEM = ITEMS.register("block", () -> new BlockItem(ModBlocks.BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> RAW_BLOCK_ITEM = ITEMS.register("raw_block", () -> new BlockItem(ModBlocks.RAW_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> ALLOY_BLOCK_ITEM = ITEMS.register("alloy_block", () -> new BlockItem(ModBlocks.ALLOY_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> ORE_ITEM = ITEMS.register("ore", () -> new BlockItem(ModBlocks.ORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> DEEPSLATE_ORE_ITEM = ITEMS.register("deepslate_ore", () -> new BlockItem(ModBlocks.DEEPSLATE_ORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> CASING_ITEM = ITEMS.register("casing", () -> new BlockItem(ModBlocks.CASING.get(), new Item.Properties()));
    public static final RegistryObject<Item> REINFORCED_BLOCK_ITEM = ITEMS.register("reinforced_block", () -> new BlockItem(ModBlocks.REINFORCED_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> GENERATOR_ITEM = ITEMS.register("generator", () -> new BlockItem(ModBlocks.GENERATOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> PROCESSOR_ITEM = ITEMS.register("processor", () -> new BlockItem(ModBlocks.PROCESSOR.get(), new Item.Properties()));
    public static final RegistryObject<Item> INFUSER_ITEM = ITEMS.register("infuser", () -> new BlockItem(ModBlocks.INFUSER.get(), new Item.Properties()));

    // ============ SEQUENCED ASSEMBLY TRANSITIONAL ITEMS ============
    public static final RegistryObject<Item> INCOMPLETE_PROCESSOR = ITEMS.register("incomplete_processor",
            () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> INCOMPLETE_INFUSER = ITEMS.register("incomplete_infuser",
            () -> new Item(new Item.Properties().stacksTo(1)));

    // ================= FIRESTEEL SWORD CASTING =================
    // Iron sword is cut into these two components, which are then used as patterns.
    public static final RegistryObject<Item> FIRESTEEL_ALLOY_BLADE = ITEMS.register("firesteel_alloy_blade",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant()));
    public static final RegistryObject<Item> FIRESTEEL_ALLOY_HANDLE = ITEMS.register("firesteel_alloy_handle",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant()));

    // Clay molds before and after furnace hardening.
    public static final RegistryObject<Item> UNBAKED_FIRESTEEL_ALLOY_BLADE_MOLD = ITEMS.register("unbaked_firesteel_alloy_blade_mold",
            () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> UNBAKED_FIRESTEEL_ALLOY_HANDLE_MOLD = ITEMS.register("unbaked_firesteel_alloy_handle_mold",
            () -> new Item(new Item.Properties().stacksTo(1)));
    public static final RegistryObject<Item> HARDENED_FIRESTEEL_ALLOY_BLADE_MOLD = ITEMS.register("hardened_firesteel_alloy_blade_mold",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant()));
    public static final RegistryObject<Item> HARDENED_FIRESTEEL_ALLOY_HANDLE_MOLD = ITEMS.register("hardened_firesteel_alloy_handle_mold",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant()));

    // Filled molds are cooled/washed to remove the ceramic shell and expose the cast parts.
    public static final RegistryObject<Item> CAST_FIRESTEEL_ALLOY_BLADE = ITEMS.register("cast_firesteel_alloy_blade",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant()));
    public static final RegistryObject<Item> CAST_FIRESTEEL_ALLOY_HANDLE = ITEMS.register("cast_firesteel_alloy_handle",
            () -> new Item(new Item.Properties().stacksTo(1).fireResistant()));

    // Finished sword assembled by a Create Deployer.
    public static final RegistryObject<Item> FIRESTEEL_ALLOY_SWORD = ITEMS.register("firesteel_alloy_sword",
            () -> new SwordItem(ModTiers.CREATEBLOCK, 2, -2.4F,
                    new Item.Properties().stacksTo(1).fireResistant()));


    // ================= TOOLS =================
    public static final RegistryObject<Item> SWORD = ITEMS.register("sword",
            () -> new SwordItem(ModTiers.CREATEBLOCK, 4, -2.2F, new Item.Properties()));
    public static final RegistryObject<Item> PICKAXE = ITEMS.register("pickaxe",
            () -> new PickaxeItem(ModTiers.CREATEBLOCK, 1, -2.8F, new Item.Properties()));
    public static final RegistryObject<Item> AXE = ITEMS.register("axe",
            () -> new AxeItem(ModTiers.CREATEBLOCK, 6.0F, -3.1F, new Item.Properties()));
    public static final RegistryObject<Item> SHOVEL = ITEMS.register("shovel",
            () -> new ShovelItem(ModTiers.CREATEBLOCK, 1.5F, -3.0F, new Item.Properties()));
    public static final RegistryObject<Item> HOE = ITEMS.register("hoe",
            () -> new HoeItem(ModTiers.CREATEBLOCK, -2, -1.0F, new Item.Properties()));
    public static final RegistryObject<Item> PAXEL = ITEMS.register("paxel",
            () -> new PaxelItem(ModTiers.ALLOY, 9.0F, -2.4F,
                    new Item.Properties().fireResistant().rarity(net.minecraft.world.item.Rarity.EPIC)));
 


 // ================= MUSIC DISC =================
public static final RegistryObject<Item> HELLDIVERS_DISC = ITEMS.register(
        "helldivers_disc",
        () -> new RecordItem(
                15,
                ModSounds.HELLDIVERS_RAISE_FLAG,
                new Item.Properties().stacksTo(1),
                200
        )
);


    // ================= CROP =================
    public static final RegistryObject<Item> BERRY = ITEMS.register("berry",
            () -> new ItemNameBlockItem(ModBlocks.BERRY_CROP.get(), new Item.Properties().food(BERRY_FOOD)));

    // ================= FLUID BUCKET =================
    public static final RegistryObject<Item> MOLTEN_CREATEBLOCK_BUCKET = ITEMS.register("molten_createblock_bucket",
            () -> new BucketItem(ModFluids.MOLTEN_CREATEBLOCK,
                    new Item.Properties().craftRemainder(Items.BUCKET).stacksTo(1)));

                    

    public static void register(IEventBus bus) {
        ITEMS.register(bus);
    }
}
