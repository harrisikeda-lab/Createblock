package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.init.ModStorage;
import com.createblock.mod.wood.ModWoodItems;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** The Createblock creative tab (modern 1.20.1 system). */
public class ModCreativeTab {
    public static final DeferredRegister<CreativeModeTab> TABS = 
        DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Createblock.MODID);

    public static final RegistryObject<CreativeModeTab> CREATEBLOCK_TAB = TABS.register("createblock_tab", () -> CreativeModeTab.builder()
        .title(Component.translatable("itemGroup.createblock"))
        .icon(() -> new ItemStack(ModItems.INGOT.get()))
        .displayItems((params, output) -> {
            // Resources
            output.accept(ModItems.RAW_ORE.get());
            output.accept(ModItems.INGOT.get());
            output.accept(ModItems.NUGGET.get());
            output.accept(ModItems.DUST.get());
            output.accept(ModItems.PLATE.get());
            output.accept(ModItems.GEM.get());
            output.accept(ModItems.ALLOY_INGOT.get());
            output.accept(ModItems.ALLOY_NUGGET.get());

            // Tools & Weapons
            output.accept(ModItems.SWORD.get());
            output.accept(ModItems.PICKAXE.get());
            output.accept(ModItems.AXE.get());
            output.accept(ModItems.SHOVEL.get());
            output.accept(ModItems.HOE.get());
            output.accept(ModItems.PAXEL.get());
            output.accept(ModItems.HELLDIVERS_DISC.get());
            
            // Firesteel Alloy Sword Casting Pipeline
            output.accept(ModItems.FIRESTEEL_ALLOY_BLADE.get());
            output.accept(ModItems.FIRESTEEL_ALLOY_HANDLE.get());
            output.accept(ModItems.UNBAKED_FIRESTEEL_ALLOY_BLADE_MOLD.get());
            output.accept(ModItems.UNBAKED_FIRESTEEL_ALLOY_HANDLE_MOLD.get());
            output.accept(ModItems.HARDENED_FIRESTEEL_ALLOY_BLADE_MOLD.get());
            output.accept(ModItems.HARDENED_FIRESTEEL_ALLOY_HANDLE_MOLD.get());
            output.accept(ModItems.CAST_FIRESTEEL_ALLOY_BLADE.get());
            output.accept(ModItems.CAST_FIRESTEEL_ALLOY_HANDLE.get());
            output.accept(ModItems.FIRESTEEL_ALLOY_SWORD.get());

            // Food
            output.accept(ModItems.BERRY.get());
            output.accept(ModItems.ENERGY_BAR.get());
            output.accept(ModItems.GOLDEN_SNACK.get());
            output.accept(ModItems.STEW.get());
            output.accept(ModItems.SANDWICH.get());

            // Blocks
            output.accept(ModBlocks.BLOCK.get());
            output.accept(ModBlocks.RAW_BLOCK.get());
            output.accept(ModBlocks.ALLOY_BLOCK.get());
            output.accept(ModBlocks.ORE.get());
            output.accept(ModBlocks.DEEPSLATE_ORE.get());
            output.accept(ModBlocks.CASING.get());
            output.accept(ModBlocks.REINFORCED_BLOCK.get());
            output.accept(ModBlocks.GENERATOR.get());
            output.accept(ModBlocks.PROCESSOR.get());
            output.accept(ModBlocks.INFUSER.get());

            // Fluid
            output.accept(ModItems.MOLTEN_CREATEBLOCK_BUCKET.get());

            // CreateBlock underwater wood family
            output.accept(ModWoodItems.CREATEBLOCK_LOG.get());
            output.accept(ModWoodItems.STRIPPED_CREATEBLOCK_LOG.get());
            output.accept(ModWoodItems.CREATEBLOCK_WOOD.get());
            output.accept(ModWoodItems.STRIPPED_CREATEBLOCK_WOOD.get());
            output.accept(ModWoodItems.CREATEBLOCK_PLANKS.get());
            output.accept(ModWoodItems.CREATEBLOCK_STAIRS.get());
            output.accept(ModWoodItems.CREATEBLOCK_SLAB.get());
            output.accept(ModWoodItems.CREATEBLOCK_FENCE.get());
            output.accept(ModWoodItems.CREATEBLOCK_FENCE_GATE.get());
            output.accept(ModWoodItems.CREATEBLOCK_DOOR.get());
            output.accept(ModWoodItems.CREATEBLOCK_TRAPDOOR.get());
            output.accept(ModWoodItems.CREATEBLOCK_PRESSURE_PLATE.get());
            output.accept(ModWoodItems.CREATEBLOCK_BUTTON.get());
            output.accept(ModWoodItems.CREATEBLOCK_WALL.get());
            output.accept(ModWoodItems.CREATEBLOCK_SIGN.get());
            output.accept(ModWoodItems.CREATEBLOCK_HANGING_SIGN.get());
            output.accept(ModWoodItems.CREATEBLOCK_BOAT_ITEM.get());
            output.accept(ModWoodItems.CREATEBLOCK_CHEST_BOAT_ITEM.get());
            output.accept(ModWoodItems.CREATEBLOCK_SAPLING.get());
            output.accept(ModWoodItems.CREATEBLOCK_LEAVES.get());

            // Storage crates
            for (var e : ModStorage.CRATE_ITEMS.values()) {
                output.accept(e.get());
            }
            output.accept(ModStorage.STACK_UPGRADE.get());
        })
        .build());

    public static void register(IEventBus bus) {
        TABS.register(bus);
    }
}