package com.createblock.mod.worldgen;

import com.createblock.mod.Createblock;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;

/** Resource keys for CreateBlock's custom biomes. */
public class ModBiomes {

    public static final ResourceKey<Biome> CREATEBLOCK_UNDERWATER_FOREST = ResourceKey.create(
            net.minecraft.core.registries.Registries.BIOME,
            new ResourceLocation(Createblock.MODID, "createblock_underwater_forest"));
}
