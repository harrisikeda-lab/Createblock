package com.createblock.mod.worldgen;

import com.mojang.datafixers.util.Pair;
import net.minecraft.core.Registry;
import net.minecraft.resources.ResourceKey;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.biome.Biome;
import net.minecraft.world.level.biome.Climate;
import terrablender.api.Region;
import terrablender.api.RegionType;

import java.util.function.Consumer;

/**
 * Inserts CreateBlock's Underwater Forest into the vanilla Overworld via TerraBlender.
 * Targets a deep-ocean-like continentalness band with a narrow weirdness slice so the
 * biome is uncommon (roughly the 2-5 relative rarity the design calls for) rather than
 * replacing normal deep ocean everywhere.
 */
public class ModOverworldRegion extends Region {

    public ModOverworldRegion(ResourceLocation name, int weight) {
        super(name, RegionType.OVERWORLD, weight);
    }

    @Override
    public void addBiomes(Registry<Biome> registry, Consumer<Pair<Climate.ParameterPoint, ResourceKey<Biome>>> mapper) {
        // Deep ocean / ocean continentalness band, mild temperature/humidity, a narrow
        // weirdness slice (keeps it rarer than the surrounding vanilla ocean biomes)
        // and depth 0 (a normal surface-reachable Overworld biome, like every ocean biome).
        Climate.ParameterPoint point = Climate.parameters(
                Climate.Parameter.span(-0.35F, 0.2F),   // temperature: cool-to-mild
                Climate.Parameter.span(0.2F, 1.0F),     // humidity: moderate-to-humid
                Climate.Parameter.span(-1.05F, -0.455F), // continentalness: deep ocean/ocean
                Climate.Parameter.span(-0.78F, 0.4F),   // erosion: broad, avoids extreme terrain
                Climate.Parameter.point(0.0F),          // depth: standard surface-reachable biome
                Climate.Parameter.span(-0.16F, 0.16F),  // weirdness: narrow slice -> uncommon
                0.0F
        );
        mapper.accept(Pair.of(point, ModBiomes.CREATEBLOCK_UNDERWATER_FOREST));
    }
}
