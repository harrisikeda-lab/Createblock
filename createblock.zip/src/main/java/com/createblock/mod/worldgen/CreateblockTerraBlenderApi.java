package com.createblock.mod.worldgen;

import com.createblock.mod.Createblock;
import net.minecraft.resources.ResourceLocation;
import terrablender.api.Regions;
import terrablender.api.TerraBlenderApi;

/** Registers CreateBlock's Overworld region with TerraBlender, discovered via ServiceLoader. */
public class CreateblockTerraBlenderApi implements TerraBlenderApi {

    @Override
    public void onTerraBlenderInitialized() {
        Regions.register(new ModOverworldRegion(new ResourceLocation(Createblock.MODID, "overworld"), 2));
    }
}
