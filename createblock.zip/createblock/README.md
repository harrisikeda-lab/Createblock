# Createblock — Forge Mod (Minecraft 1.20.1)

A standalone Forge mod version of the Createblock content: a custom
resource line, alloys, decorative machine blocks, and foods, with
optional Create integration.

**Create is a soft dependency** — the mod loads fine without it. The
Create recipes (crushing/pressing/mixing/deploying/compacting) live in
`data/createblock/recipes/compat/` and are gated behind a
`forge:mod_loaded` condition, so they simply don't load if Create is absent.

---

## Build it

You need **JDK 17** (not 8, not 21).

```bash
cd createblock
./gradlew build          # Linux / macOS / Raspberry Pi
gradlew.bat build        # Windows
```

First build downloads Forge + Create + dependencies (a few GB, slow on a Pi).
Later builds are much faster.

**Output jar:** `build/libs/createblock-1.0.0.jar`

Drop that jar into your instance's `mods/` folder.

### Missing gradlew?
This zip ships `gradle/wrapper/gradle-wrapper.properties` but not the
wrapper binary. If `./gradlew` is missing, generate it once with a local
Gradle install:

```bash
gradle wrapper --gradle-version 8.1.1
```

Or just run `gradle build` directly if you have Gradle 8.x installed.

### Run it in a dev client

```bash
./gradlew runClient
```

To test *with* Create in dev, uncomment the `runtimeOnly` lines in
`build.gradle`.

---

## What's inside

**Items (12):** raw_ore, ingot, nugget, dust, plate, gem, alloy_ingot,
alloy_nugget, energy_bar, golden_snack, stew, sandwich

**Blocks (10):** block, raw_block, alloy_block, ore, deepslate_ore,
casing, reinforced_block, generator (directional, distinct front/top),
processor, infuser

**Tools (4):**
| Tool | Tier | Damage | Notes |
|---|---|---|---|
| Sword | Createblock | 4 | between diamond and netherite |
| Pickaxe | Createblock | 1 | |
| Axe | Createblock | 6 | |
| **Paxel** | **Alloy** | **9** | **pickaxe + axe + shovel in one**, 4096 durability, speed 14, fire-resistant, EPIC rarity |

The Paxel is a genuine all-in-one: it mines every pickaxe/axe/shovel block
at full speed, strips logs, scrapes copper, makes dirt paths — all of it.
It is deliberately the hardest thing in the mod to get.

**Crop (1):** Createblock Berry — plantable on farmland, 8 stages,
drops 1-3 when mature. Small food.

**Fluid (1):** Molten Createblock — animated teal molten metal, plus its
bucket. Lava-like physics (thick, slow-spreading, 1300K, doesn't
extinguish, can't swim/boat in it), emits light level 12, custom fog.

**Creative tab:** "Createblock", icon = the ingot.

**Foods:**
| Item | Hunger | Sat. | Effects |
|---|---|---|---|
| Energy Bar | 6 | 0.8 | Speed I (20s), fast to eat |
| Golden Snack | 8 | 1.2 | Absorption I (60s) + Regen II (5s), always edible |
| Stew | 8 | 0.9 | Saturation (5s), returns bowl, stacks to 1 |
| Sandwich | 7 | 0.9 | fast to eat |

**Ores** drop `raw_ore` with Fortune support; Silk Touch drops the block.

---

## Recipes — tuned to be HARD

This mod is deliberately grindy. Nothing here is handed to you.

- 9↔1 compaction for ingot/nugget/block and the alloy line
- Smelting/blasting: **raw_ore → ingot** and **dust → ingot** only.
  (Direct ore→ingot smelting was REMOVED — you must process ore through
  crushing into dust, so Create is the real path.)
- `raw_ore` bootstrap craft: **4 iron ingots + 4 andesite + 1 amethyst**
  (expensive on purpose; one-block packs can still start the line)
- **Casing:** 4 plates + 4 ingots + an andesite casing
- **Gem:** 8 dust + 1 amethyst shard
- Machines craft from plates/gems/casing/alloy

### Tool progression
1. Ingots + plates → Sword / Pickaxe / Axe (Createblock tier)
2. Alloy (superheated mixing, needs **netherite scrap**) → alloy blocks
3. **Paxel** = Pickaxe + Axe + Infuser + Alloy Block + Reinforced Block
   + 4 Gems. You must have built the entire tech tree first.

### With Create — also harder
- Crushing ore → dust is **1 dust + a small bonus chance** (was 2x).
  Ore doubling is now a *bonus*, not a guarantee.
- The **alloy** requires **superheated** mixing plus a netherite scrap.
- Melting to Molten Createblock requires **superheated** (blaze cake).

**With Create installed**, you also get:
- Crushing: ore/deepslate_ore/raw_ore → dust (with ore-doubling)
- Pressing: ingot → plate
- Mixing (heated): ingot + dust + gold → alloy_ingot
- Deploying: andesite casing + ingot → casing
- Compacting: 9 dust → ingot

**Molten Createblock (Create only):**
- Mixing (**superheated**): ingot → 90mB molten; block → 810mB
- Filling: iron nugget + 90mB molten → ingot (casting it back)
- Emptying: molten bucket → 1000mB + empty bucket
- Mixing (heated): dust + gold + 90mB molten → 2x alloy_ingot

Superheated means a **Blaze Burner fed blaze cake** — melting metal
should be harder than normal heating.

### Fluid textures
`assets/createblock/textures/fluid/` holds a 16-frame animated still
and flow texture (16x256 PNG + `.mcmeta`). Replace them with your own
art any time — keep the filenames and the 16-frames-of-16x16 layout.

---

## Project layout

```
src/main/java/com/createblock/mod/
  Createblock.java            main mod class
  init/ModBlocks.java         block registry
  init/ModItems.java          item registry (incl. block-items, foods)
  init/ModCreativeTab.java    creative tab
  block/GeneratorBlock.java   directional machine block
  item/StewItem.java          returns a bowl when eaten

src/main/resources/
  META-INF/mods.toml          mod metadata + soft Create dependency
  assets/createblock/         textures, models, blockstates, lang
  data/createblock/           recipes, loot tables, tags
  data/createblock/recipes/compat/   Create-gated recipes
```

## Changing things

- **Item stats / foods** → `init/ModItems.java`
- **Block hardness / sound** → `init/ModBlocks.java`
- **Recipes** → the JSON files in `data/createblock/recipes/`
- **Textures** → replace the PNG in `assets/createblock/textures/`,
  keep the filename

## Notes

- Uses `DeferredRegister` and the modern 1.20.1 creative tab system.
- Create's version is pinned in `gradle.properties` (`create_version`).
  If your Create build differs, update it there.
- If Create's maven is unreachable, you can comment out the three
  `compileOnly` Create lines and the mod still builds — you'd just lose
  compile-time access to Create (the JSON recipes still work at runtime).
