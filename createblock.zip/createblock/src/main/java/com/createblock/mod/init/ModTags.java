package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.level.block.Block;

/** Tag keys used by the mod. */
public class ModTags {

    public static class Blocks {
        /** Union of pickaxe + axe + shovel mineable blocks — what the Paxel digs. */
        public static final TagKey<Block> PAXEL_MINEABLE = create("mineable/paxel");

        private static TagKey<Block> create(String path) {
            return TagKey.create(Registries.BLOCK, new ResourceLocation(Createblock.MODID, path));
        }
    }
}
