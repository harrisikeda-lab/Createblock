package com.createblock.mod.machine;

import com.createblock.mod.Config;
import com.createblock.mod.init.ModItems;
import com.createblock.mod.init.ModMachines;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

/**
 * The Generator: burns fuel (like a furnace) and, while burning, slowly
 * produces Createblock nuggets into its output slot. No Create dependency.
 *
 * Slot 0 = fuel input, Slot 1 = output.
 */
public class GeneratorBlockEntity extends BlockEntity implements net.minecraft.world.MenuProvider {

    private final ItemStackHandler items = new ItemStackHandler(2) {
        @Override protected void onContentsChanged(int slot) { setChanged(); }
        @Override public boolean isItemValid(int slot, @NotNull ItemStack stack) {
            if (slot == 0) return ForgeHooks.getBurnTime(stack, null) > 0;
            return false; // output only
        }
    };

    private final LazyOptional<IItemHandler> itemHandler = LazyOptional.of(() -> items);

    private int litTime;       // ticks of fuel remaining
    private int litDuration;   // total burn time of current fuel
    private int progress;      // ticks toward next produced item

    private final ContainerData data = new ContainerData() {
        @Override public int get(int i) {
            return switch (i) {
                case 0 -> litTime;
                case 1 -> litDuration;
                case 2 -> progress;
                default -> 0;
            };
        }
        @Override public void set(int i, int v) {
            switch (i) {
                case 0 -> litTime = v;
                case 1 -> litDuration = v;
                case 2 -> progress = v;
            }
        }
        @Override public int getCount() { return 3; }
    };

    public GeneratorBlockEntity(BlockPos pos, BlockState state) {
        super(ModMachines.GENERATOR_BE.get(), pos, state);
    }

    public ContainerData getData() { return data; }
    public ItemStackHandler getItems() { return items; }

    private boolean isLit() { return litTime > 0; }

    public static void tick(Level level, BlockPos pos, BlockState state, GeneratorBlockEntity be) {
        if (level.isClientSide) return;
        boolean changed = false;

        // consume fuel if not lit
        if (!be.isLit()) {
            ItemStack fuel = be.items.getStackInSlot(0);
            if (!fuel.isEmpty()) {
                int burn = ForgeHooks.getBurnTime(fuel, null);
                if (burn > 0) {
                    be.litTime = burn;
                    be.litDuration = burn;
                    ItemStack container = fuel.getCraftingRemainingItem();
                    fuel.shrink(1);
                    if (fuel.isEmpty() && !container.isEmpty())
                        be.items.setStackInSlot(0, container);
                    changed = true;
                }
            }
        }

        // while lit, make progress
        if (be.isLit()) {
            be.litTime--;
            be.progress++;
            int need = Config.generatorTicksPerItem;
            if (be.progress >= need) {
                be.progress = 0;
                be.produce();
                changed = true;
            }
        } else {
            be.progress = 0;
        }

        if (changed) setChangedAndSync(level, pos, state, be);
    }

    private void produce() {
        // output a Createblock nugget (a slow trickle of resource)
        ItemStack out = items.getStackInSlot(1);
        ItemStack nugget = new ItemStack(ModItems.NUGGET.get());
        if (out.isEmpty()) {
            items.setStackInSlot(1, nugget);
        } else if (ItemStack.isSameItem(out, nugget) && out.getCount() < out.getMaxStackSize()) {
            out.grow(1);
        }
        // if full, output is simply skipped this cycle
    }

    private static void setChangedAndSync(Level level, BlockPos pos, BlockState state, BlockEntity be) {
        be.setChanged();
        level.sendBlockUpdated(pos, state, state, 3);
    }

    // ---- MenuProvider ----
    @Override
    public Component getDisplayName() { return Component.translatable("block.createblock.generator"); }

    @Nullable
    @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player player) {
        return new GeneratorMenu(id, inv, this, this.data);
    }

    // ---- capability ----
    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return itemHandler.cast();
        return super.getCapability(cap, side);
    }

    @Override public void invalidateCaps() { super.invalidateCaps(); itemHandler.invalidate(); }

    public void drops() {
        SimpleContainer inv = new SimpleContainer(items.getSlots());
        for (int i = 0; i < items.getSlots(); i++) inv.setItem(i, items.getStackInSlot(i));
        Containers.dropContents(this.level, this.worldPosition, inv);
    }

    // ---- save/load ----
    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inv", items.serializeNBT());
        tag.putInt("LitTime", litTime);
        tag.putInt("LitDuration", litDuration);
        tag.putInt("Progress", progress);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        items.deserializeNBT(tag.getCompound("Inv"));
        litTime = tag.getInt("LitTime");
        litDuration = tag.getInt("LitDuration");
        progress = tag.getInt("Progress");
    }
}
