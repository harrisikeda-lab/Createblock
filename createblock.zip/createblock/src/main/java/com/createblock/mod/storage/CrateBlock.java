package com.createblock.mod.storage;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.MenuProvider;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.network.NetworkHooks;
import org.jetbrains.annotations.Nullable;

/** A storage crate block. Its tier is baked in at construction. */
public class CrateBlock extends BaseEntityBlock {

    private final CrateTier tier;

    public CrateBlock(Properties props, CrateTier tier) {
        super(props);
        this.tier = tier;
    }

    public CrateTier getTier() { return tier; }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new CrateBlockEntity(pos, state, tier);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos,
                                 Player player, InteractionHand hand, net.minecraft.world.phys.BlockHitResult hit) {
        BlockEntity beCheck = level.getBlockEntity(pos);
        ItemStack held = player.getItemInHand(hand);
        // Stack upgrade: right-click the crate with the upgrade item.
        if (beCheck instanceof CrateBlockEntity crateBE
                && held.is(com.createblock.mod.init.ModStorage.STACK_UPGRADE.get())) {
            if (!level.isClientSide) {
                int cur = crateBE.getStackMultiplier();
                if (cur < 16) {                 // cap at 16x (1024/slot)
                    crateBE.setStackMultiplier(cur * 2);
                    if (!player.getAbilities().instabuild) held.shrink(1);
                    level.playSound(null, pos, net.minecraft.sounds.SoundEvents.ANVIL_USE,
                            net.minecraft.sounds.SoundSource.BLOCKS, 0.6F, 1.4F);
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (!level.isClientSide) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof CrateBlockEntity crate) {
                NetworkHooks.openScreen((net.minecraft.server.level.ServerPlayer) player,
                        new MenuProvider() {
                            @Override
                            public Component getDisplayName() {
                                return Component.translatable("block.createblock." + tier.id + "_crate");
                            }
                            @Nullable
                            @Override
                            public AbstractContainerMenu createMenu(int id, Inventory inv, Player p) {
                                return new CrateMenu(id, inv, crate);
                            }
                        },
                        buf -> buf.writeByte(tier.ordinal()));
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    // Drop contents when broken
    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean moved) {
        if (!state.is(newState.getBlock())) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof CrateBlockEntity crate) {
                net.minecraft.world.Containers.dropContents(level, pos, crate);
            }
            super.onRemove(state, level, pos, newState, moved);
        }
    }
}
