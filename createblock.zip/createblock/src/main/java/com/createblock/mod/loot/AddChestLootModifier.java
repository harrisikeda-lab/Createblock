package com.createblock.mod.loot;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import it.unimi.dsi.fastutil.objects.ObjectArrayList;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.storage.loot.LootContext;
import net.minecraft.world.level.storage.loot.predicates.LootItemCondition;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.common.loot.LootModifier;
import org.jetbrains.annotations.NotNull;

/**
 * Adds an item stack (random count between min and max) to a loot table,
 * gated by the conditions in the JSON (loot_table_id + random_chance).
 */
public class AddChestLootModifier extends LootModifier {

    public static final Codec<AddChestLootModifier> CODEC =
            RecordCodecBuilder.create(inst -> LootModifier.codecStart(inst).and(inst.group(
                    ResourceLocation.CODEC.fieldOf("item").forGetter(m -> m.itemId),
                    Codec.INT.fieldOf("min").forGetter(m -> m.min),
                    Codec.INT.fieldOf("max").forGetter(m -> m.max)
            )).apply(inst, AddChestLootModifier::new));

    private final ResourceLocation itemId;
    private final int min;
    private final int max;

    public AddChestLootModifier(LootItemCondition[] conditions, ResourceLocation itemId, int min, int max) {
        super(conditions);
        this.itemId = itemId;
        this.min = min;
        this.max = max;
    }

    @NotNull
    @Override
    protected ObjectArrayList<ItemStack> doApply(ObjectArrayList<ItemStack> loot, LootContext context) {
        Item item = BuiltInRegistries.ITEM.get(itemId);
        int count = min >= max ? min : min + context.getRandom().nextInt(max - min + 1);
        if (count > 0) {
            loot.add(new ItemStack(item, count));
        }
        return loot;
    }

    @Override
    public Codec<? extends IGlobalLootModifier> codec() {
        return CODEC;
    }
}
