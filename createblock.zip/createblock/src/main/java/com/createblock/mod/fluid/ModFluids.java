package com.createblock.mod.fluid;

import com.createblock.mod.Createblock;
import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.init.ModItems;
import net.minecraft.world.level.material.FlowingFluid;
import net.minecraft.world.level.material.Fluid;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fluids.ForgeFlowingFluid;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** The actual fluid (source + flowing variants). */
public class ModFluids {

    public static final DeferredRegister<Fluid> FLUIDS =
            DeferredRegister.create(ForgeRegistries.FLUIDS, Createblock.MODID);

    public static final RegistryObject<FlowingFluid> MOLTEN_CREATEBLOCK =
            FLUIDS.register("molten_createblock",
                    () -> new ForgeFlowingFluid.Source(ModFluids.MOLTEN_PROPERTIES));

    public static final RegistryObject<FlowingFluid> FLOWING_MOLTEN_CREATEBLOCK =
            FLUIDS.register("flowing_molten_createblock",
                    () -> new ForgeFlowingFluid.Flowing(ModFluids.MOLTEN_PROPERTIES));

    public static final ForgeFlowingFluid.Properties MOLTEN_PROPERTIES =
            new ForgeFlowingFluid.Properties(
                    ModFluidTypes.MOLTEN_CREATEBLOCK_TYPE,
                    MOLTEN_CREATEBLOCK,
                    FLOWING_MOLTEN_CREATEBLOCK)
                    .slopeFindDistance(2)      // spreads like lava, not water
                    .levelDecreasePerBlock(2)
                    .block(ModBlocks.MOLTEN_CREATEBLOCK_BLOCK)
                    .bucket(ModItems.MOLTEN_CREATEBLOCK_BUCKET);

    public static void register(IEventBus bus) {
        FLUIDS.register(bus);
    }
}
