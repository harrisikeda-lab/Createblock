package com.createblock.mod.compat.jei;

import com.createblock.mod.Createblock;
import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.init.ModRecipes;
import com.createblock.mod.recipe.InfuserRecipe;
import com.createblock.mod.recipe.ProcessorRecipe;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.registration.IRecipeCategoryRegistration;
import mezz.jei.api.registration.IRecipeCatalystRegistration;
import mezz.jei.api.registration.IRecipeRegistration;
import net.minecraft.client.Minecraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.RecipeManager;
import net.minecraft.world.item.crafting.RecipeType;

import java.util.List;

/**
 * JEI integration. Only loads when JEI is present (compileOnly dependency).
 * Registers the Processor and Infuser custom recipe categories.
 */
@JeiPlugin
public class CreateblockJeiPlugin implements IModPlugin {

    public static final ResourceLocation UID = new ResourceLocation(Createblock.MODID, "jei");

    @Override
    public ResourceLocation getPluginUid() { return UID; }

    @Override
    public void registerCategories(IRecipeCategoryRegistration reg) {
        reg.addRecipeCategories(new ProcessorRecipeCategory(reg.getJeiHelpers().getGuiHelper()));
        reg.addRecipeCategories(new InfuserRecipeCategory(reg.getJeiHelpers().getGuiHelper()));
    }

    @Override
    public void registerRecipes(IRecipeRegistration reg) {
        RecipeManager rm = Minecraft.getInstance().level.getRecipeManager();

        List<ProcessorRecipe> processing = rm.getAllRecipesFor(ModRecipes.PROCESSOR_TYPE.get());
        reg.addRecipes(ProcessorRecipeCategory.TYPE, processing);

        List<InfuserRecipe> infusing = rm.getAllRecipesFor(ModRecipes.INFUSER_TYPE.get());
        reg.addRecipes(InfuserRecipeCategory.TYPE, infusing);
    }

    @Override
    public void registerRecipeCatalysts(IRecipeCatalystRegistration reg) {
        reg.addRecipeCatalyst(new ItemStack(ModBlocks.PROCESSOR.get()), ProcessorRecipeCategory.TYPE);
        reg.addRecipeCatalyst(new ItemStack(ModBlocks.INFUSER.get()), InfuserRecipeCategory.TYPE);
    }
}
