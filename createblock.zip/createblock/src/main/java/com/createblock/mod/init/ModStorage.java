package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.storage.CrateBlock;
import com.createblock.mod.storage.CrateBlockEntity;
import com.createblock.mod.storage.CrateMenu;
import com.createblock.mod.storage.CrateTier;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.inventory.MenuType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.Map;

/** Registration for the storage crate system (blocks, items, BE, menu). */
public class ModStorage {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Createblock.MODID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, Createblock.MODID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Createblock.MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, Createblock.MODID);

    // One block + block-item per tier.
    public static final Map<CrateTier, RegistryObject<Block>> CRATE_BLOCKS = new EnumMap<>(CrateTier.class);
    public static final Map<CrateTier, RegistryObject<Item>> CRATE_ITEMS = new EnumMap<>(CrateTier.class);

    static {
        for (CrateTier tier : CrateTier.values()) {
            String name = tier.id + "_crate";
            RegistryObject<Block> block = BLOCKS.register(name,
                    () -> new CrateBlock(BlockBehaviour.Properties.of()
                            .mapColor(MapColor.WOOD)
                            .strength(2.5F)
                            .sound(SoundType.WOOD), tier));
            CRATE_BLOCKS.put(tier, block);
            CRATE_ITEMS.put(tier, ITEMS.register(name,
                    () -> new BlockItem(block.get(), new Item.Properties())));
        }
    }

    // Stack upgrade item — right-click-applied in a crafting recipe (see recipes).
    public static final RegistryObject<Item> STACK_UPGRADE = ITEMS.register("crate_stack_upgrade",
            () -> new Item(new Item.Properties()));

    // ONE block entity type serving every crate block.
    public static final RegistryObject<BlockEntityType<CrateBlockEntity>> CRATE_BE =
            BLOCK_ENTITIES.register("crate", () -> BlockEntityType.Builder.of(
                    (pos, state) -> {
                        Block b = state.getBlock();
                        CrateTier tier = (b instanceof CrateBlock cb) ? cb.getTier() : CrateTier.WOOD;
                        return new CrateBlockEntity(pos, state, tier);
                    },
                    CRATE_BLOCKS.values().stream().map(RegistryObject::get).toArray(Block[]::new)
            ).build(null));

    public static final RegistryObject<MenuType<CrateMenu>> CRATE_MENU =
            MENUS.register("crate", () -> IForgeMenuType.create(CrateMenu::new));

    public static final RegistryObject<MenuType<com.createblock.mod.storage.CrateUpgradeMenu>> CRATE_UPGRADE_MENU =
            MENUS.register("crate_upgrade",
                    () -> IForgeMenuType.create(com.createblock.mod.storage.CrateUpgradeMenu::new));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
        ITEMS.register(bus);
        BLOCK_ENTITIES.register(bus);
        MENUS.register(bus);
    }
}
