package com.createblock.mod.storage;

import com.createblock.mod.Createblock;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;

/**
 * The "Apply Upgrade" screen. Shows tier name and total capacity now vs.
 * after the next upgrade, with an Apply button.
 */
public class CrateUpgradeScreen extends AbstractContainerScreen<CrateUpgradeMenu> {

    private static final ResourceLocation BG =
            new ResourceLocation(Createblock.MODID, "textures/gui/crate_upgrade.png");

    private Button applyButton;

    public CrateUpgradeScreen(CrateUpgradeMenu menu, Inventory inv, Component title) {
        super(menu, inv, title);
        this.imageWidth = 176;
        this.imageHeight = 130;
    }

    @Override
    protected void init() {
        super.init();
        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;
        applyButton = Button.builder(Component.literal("Apply Upgrade"),
                b -> {
                    if (minecraft != null && minecraft.gameMode != null)
                        minecraft.gameMode.handleInventoryButtonClick(menu.containerId, 0);
                })
                .bounds(x + 38, y + 96, 100, 20)
                .build();
        addRenderableWidget(applyButton);
    }

    private long totalCapacity(int mult) {
        return (long) menu.getTier().slots * 64L * mult;
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;
        g.blit(BG, x, y, 0, 0, imageWidth, imageHeight);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);

        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;
        int mult = menu.getMultiplier();
        boolean maxed = mult >= 16;

        // Tier name
        String tierName = capitalize(menu.getTier().id) + " Storage Crate";
        g.drawCenteredString(font, tierName, x + imageWidth/2, y + 10, 0x404040);

        // Current capacity
        String now = "Now: " + menu.getTier().slots + " slots x " + (64*mult)
                + " = " + totalCapacity(mult) + " items";
        g.drawString(font, now, x + 12, y + 34, 0x404040, false);

        // After upgrade (or maxed)
        if (maxed) {
            g.drawString(font, "Maximum upgrade reached.", x + 12, y + 52, 0xAA0000, false);
        } else {
            String next = "After: " + menu.getTier().slots + " slots x " + (64*mult*2)
                    + " = " + totalCapacity(mult*2) + " items";
            g.drawString(font, next, x + 12, y + 52, 0x207020, false);
        }

        if (applyButton != null) applyButton.active = !maxed;

        this.renderTooltip(g, mouseX, mouseY);
    }

    @Override
    protected void renderLabels(GuiGraphics g, int mouseX, int mouseY) {
        // suppress default labels; we draw our own
    }

    private static String capitalize(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }
}
