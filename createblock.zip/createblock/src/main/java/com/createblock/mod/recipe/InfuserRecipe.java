package com.createblock.mod.recipe;

import com.createblock.mod.init.ModRecipes;
import com.google.gson.JsonObject;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.SimpleContainer;

/** Two-input infusing recipe: inputA + inputB -> output after time ticks. */
public class InfuserRecipe implements Recipe<SimpleContainer> {

    private final ResourceLocation id;
    private final Ingredient inputA;
    private final Ingredient inputB;
    private final ItemStack output;
    private final int time;

    public InfuserRecipe(ResourceLocation id, Ingredient a, Ingredient b, ItemStack output, int time) {
        this.id = id; this.inputA = a; this.inputB = b; this.output = output; this.time = time;
    }

    public int getTime() { return time; }
    public Ingredient getInputA() { return inputA; }
    public Ingredient getInputB() { return inputB; }

    @Override
    public boolean matches(SimpleContainer c, Level level) {
        // accept either arrangement across slots 0 and 1
        ItemStack s0 = c.getItem(0), s1 = c.getItem(1);
        return (inputA.test(s0) && inputB.test(s1)) || (inputA.test(s1) && inputB.test(s0));
    }

    @Override
    public ItemStack assemble(SimpleContainer c, net.minecraft.core.RegistryAccess reg) { return output.copy(); }
    @Override public boolean canCraftInDimensions(int w, int h) { return true; }
    @Override public ItemStack getResultItem(net.minecraft.core.RegistryAccess reg) { return output.copy(); }
    @Override public ResourceLocation getId() { return id; }
    @Override public RecipeSerializer<?> getSerializer() { return ModRecipes.INFUSER_SERIALIZER.get(); }
    @Override public RecipeType<?> getType() { return ModRecipes.INFUSER_TYPE.get(); }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        list.add(inputA); list.add(inputB);
        return list;
    }

    public static class Serializer implements RecipeSerializer<InfuserRecipe> {
        @Override
        public InfuserRecipe fromJson(ResourceLocation id, JsonObject json) {
            Ingredient a = Ingredient.fromJson(GsonHelper.getAsJsonObject(json, "inputA"));
            Ingredient b = Ingredient.fromJson(GsonHelper.getAsJsonObject(json, "inputB"));
            JsonObject res = GsonHelper.getAsJsonObject(json, "result");
            ItemStack out = new ItemStack(
                    net.minecraft.core.registries.BuiltInRegistries.ITEM.get(
                            new ResourceLocation(GsonHelper.getAsString(res, "item"))),
                    GsonHelper.getAsInt(res, "count", 1));
            int time = GsonHelper.getAsInt(json, "time", 200);
            return new InfuserRecipe(id, a, b, out, time);
        }

        @Override
        public InfuserRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            Ingredient a = Ingredient.fromNetwork(buf);
            Ingredient b = Ingredient.fromNetwork(buf);
            ItemStack out = buf.readItem();
            int time = buf.readVarInt();
            return new InfuserRecipe(id, a, b, out, time);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, InfuserRecipe r) {
            r.inputA.toNetwork(buf);
            r.inputB.toNetwork(buf);
            buf.writeItem(r.output);
            buf.writeVarInt(r.time);
        }
    }
}
