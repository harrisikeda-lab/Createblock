package com.createblock.mod.recipe;

import com.createblock.mod.init.ModRecipes;
import com.google.gson.JsonObject;
import net.minecraft.core.NonNullList;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.crafting.Recipe;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraft.world.level.Level;
import net.minecraft.util.GsonHelper;
import net.minecraft.world.SimpleContainer;

/** A single-input processing recipe: input -> output after processingTime ticks. */
public class ProcessorRecipe implements Recipe<SimpleContainer> {

    private final ResourceLocation id;
    private final Ingredient input;
    private final int inputCount;
    private final ItemStack output;
    private final int time;

    public ProcessorRecipe(ResourceLocation id, Ingredient input, int inputCount, ItemStack output, int time) {
        this.id = id;
        this.input = input;
        this.inputCount = inputCount;
        this.output = output;
        this.time = time;
    }

    public int getTime() { return time; }
    public int getInputCount() { return inputCount; }
    public Ingredient getInput() { return input; }

    @Override
    public boolean matches(SimpleContainer c, Level level) {
        ItemStack in = c.getItem(0);
        return input.test(in) && in.getCount() >= inputCount;
    }

    @Override
    public ItemStack assemble(SimpleContainer c, net.minecraft.core.RegistryAccess reg) {
        return output.copy();
    }

    @Override public boolean canCraftInDimensions(int w, int h) { return true; }
    @Override public ItemStack getResultItem(net.minecraft.core.RegistryAccess reg) { return output.copy(); }
    @Override public ResourceLocation getId() { return id; }
    @Override public RecipeSerializer<?> getSerializer() { return ModRecipes.PROCESSOR_SERIALIZER.get(); }
    @Override public RecipeType<?> getType() { return ModRecipes.PROCESSOR_TYPE.get(); }

    @Override
    public NonNullList<Ingredient> getIngredients() {
        NonNullList<Ingredient> list = NonNullList.create();
        list.add(input);
        return list;
    }

    public static class Serializer implements RecipeSerializer<ProcessorRecipe> {
        @Override
        public ProcessorRecipe fromJson(ResourceLocation id, JsonObject json) {
            Ingredient ing = Ingredient.fromJson(GsonHelper.getAsJsonObject(json, "ingredient"));
            int inCount = GsonHelper.getAsInt(json, "inputCount", 1);
            JsonObject res = GsonHelper.getAsJsonObject(json, "result");
            ItemStack out = new ItemStack(
                    net.minecraft.core.registries.BuiltInRegistries.ITEM.get(
                            new ResourceLocation(GsonHelper.getAsString(res, "item"))),
                    GsonHelper.getAsInt(res, "count", 1));
            int time = GsonHelper.getAsInt(json, "time", 200);
            return new ProcessorRecipe(id, ing, inCount, out, time);
        }

        @Override
        public ProcessorRecipe fromNetwork(ResourceLocation id, FriendlyByteBuf buf) {
            Ingredient ing = Ingredient.fromNetwork(buf);
            int inCount = buf.readVarInt();
            ItemStack out = buf.readItem();
            int time = buf.readVarInt();
            return new ProcessorRecipe(id, ing, inCount, out, time);
        }

        @Override
        public void toNetwork(FriendlyByteBuf buf, ProcessorRecipe r) {
            r.input.toNetwork(buf);
            buf.writeVarInt(r.inputCount);
            buf.writeItem(r.output);
            buf.writeVarInt(r.time);
        }
    }
}
