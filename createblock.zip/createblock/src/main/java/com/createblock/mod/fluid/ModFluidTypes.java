package com.createblock.mod.fluid;

import com.createblock.mod.Createblock;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.level.material.FluidType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/**
 * The FluidType carries the "physical" properties: how it looks, sounds,
 * how fast you move in it, fog colour, etc.
 */
public class ModFluidTypes {

    public static final ResourceLocation STILL_TEXTURE =
            new ResourceLocation(Createblock.MODID, "fluid/molten_createblock_still");
    public static final ResourceLocation FLOW_TEXTURE =
            new ResourceLocation(Createblock.MODID, "fluid/molten_createblock_flow");
    public static final ResourceLocation OVERLAY_TEXTURE =
            new ResourceLocation("block/water_overlay");

    public static final DeferredRegister<FluidType> FLUID_TYPES =
            DeferredRegister.create(ForgeRegistries.Keys.FLUID_TYPES, Createblock.MODID);

    public static final RegistryObject<FluidType> MOLTEN_CREATEBLOCK_TYPE =
            FLUID_TYPES.register("molten_createblock", () -> new BaseFluidType(
                    STILL_TEXTURE, FLOW_TEXTURE, OVERLAY_TEXTURE,
                    0xA020C0B0,                 // ARGB tint (teal, semi-transparent)
                    new org.joml.Vector3f(32f / 255f, 158f / 255f, 162f / 255f), // fog colour
                    FluidType.Properties.create()
                            .density(3000)          // thick, like lava
                            .viscosity(6000)
                            .temperature(1300)      // molten metal: HOT
                            .canDrown(false)
                            .canSwim(false)
                            .canExtinguish(false)
                            .canConvertToSource(false)
                            .supportsBoating(false)
                            .sound(net.minecraftforge.common.SoundActions.BUCKET_FILL,
                                    SoundEvents.BUCKET_FILL_LAVA)
                            .sound(net.minecraftforge.common.SoundActions.BUCKET_EMPTY,
                                    SoundEvents.BUCKET_EMPTY_LAVA)
            ));

    public static void register(IEventBus bus) {
        FLUID_TYPES.register(bus);
    }
}
