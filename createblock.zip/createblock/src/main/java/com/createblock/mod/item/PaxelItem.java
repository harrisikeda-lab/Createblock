package com.createblock.mod.item;

import net.minecraft.tags.BlockTags;
import net.minecraft.world.item.DiggerItem;
import net.minecraft.world.item.Tier;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.InteractionResult;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.Level;
import net.minecraft.world.entity.player.Player;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraftforge.common.ToolActions;
import net.minecraftforge.common.ToolAction;

import java.util.Optional;

/**
 * The Paxel: a genuine pickaxe + axe + shovel in one item.
 *
 * How the "all-in-one" actually works:
 *  - We extend DiggerItem with a custom tag (createblock:mineable/paxel)
 *    that unions the vanilla pickaxe/axe/shovel mineable tags, so the tool
 *    is "correct" for all three block families and gets full dig speed.
 *  - We override isCorrectToolForDrops to accept any of the three tags,
 *    so blocks that need a tool actually drop.
 *  - canPerformAction advertises every pickaxe/axe/shovel ToolAction, so
 *    stripping logs, making paths, scraping copper etc. all work.
 *  - useOn replicates the axe (strip/scrape/wax-off) and shovel (path)
 *    right-click behaviours.
 */
public class PaxelItem extends DiggerItem {

    public PaxelItem(Tier tier, float attackDamage, float attackSpeed, Properties props) {
        // The tag here is our union tag; see data/createblock/tags/blocks/mineable/paxel.json
        super(attackDamage, attackSpeed, tier, com.createblock.mod.init.ModTags.Blocks.PAXEL_MINEABLE, props);
    }

    @Override
    public boolean isCorrectToolForDrops(ItemStack stack, BlockState state) {
        // Accept anything a pickaxe, axe, or shovel could correctly mine,
        // as long as our tier is high enough for the block's harvest level.
        if (state.is(BlockTags.MINEABLE_WITH_PICKAXE)
                || state.is(BlockTags.MINEABLE_WITH_AXE)
                || state.is(BlockTags.MINEABLE_WITH_SHOVEL)) {
            int level = this.getTier().getLevel();
            if (state.is(BlockTags.NEEDS_DIAMOND_TOOL)) return level >= 3;
            if (state.is(BlockTags.NEEDS_IRON_TOOL))    return level >= 2;
            if (state.is(BlockTags.NEEDS_STONE_TOOL))   return level >= 1;
            return true;
        }
        return false;
    }

    @Override
    public float getDestroySpeed(ItemStack stack, BlockState state) {
        // Full speed on all three families (DiggerItem only checks its own tag).
        if (state.is(BlockTags.MINEABLE_WITH_PICKAXE)
                || state.is(BlockTags.MINEABLE_WITH_AXE)
                || state.is(BlockTags.MINEABLE_WITH_SHOVEL)) {
            return this.getTier().getSpeed();
        }
        return super.getDestroySpeed(stack, state);
    }

    @Override
    public boolean canPerformAction(ItemStack stack, ToolAction action) {
        return ToolActions.DEFAULT_PICKAXE_ACTIONS.contains(action)
                || ToolActions.DEFAULT_AXE_ACTIONS.contains(action)
                || ToolActions.DEFAULT_SHOVEL_ACTIONS.contains(action);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos pos = ctx.getClickedPos();
        Player player = ctx.getPlayer();
        BlockState state = level.getBlockState(pos);

        // ---- AXE behaviours: strip / scrape / unwax ----
        Optional<BlockState> stripped =
                Optional.ofNullable(state.getToolModifiedState(ctx, ToolActions.AXE_STRIP, false));
        Optional<BlockState> scraped =
                Optional.ofNullable(state.getToolModifiedState(ctx, ToolActions.AXE_SCRAPE, false));
        Optional<BlockState> unwaxed =
                Optional.ofNullable(state.getToolModifiedState(ctx, ToolActions.AXE_WAX_OFF, false));

        BlockState result = null;
        if (stripped.isPresent()) {
            level.playSound(player, pos, SoundEvents.AXE_STRIP, SoundSource.BLOCKS, 1.0F, 1.0F);
            result = stripped.get();
        } else if (scraped.isPresent()) {
            level.playSound(player, pos, SoundEvents.AXE_SCRAPE, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.levelEvent(player, 3005, pos, 0);
            result = scraped.get();
        } else if (unwaxed.isPresent()) {
            level.playSound(player, pos, SoundEvents.AXE_WAX_OFF, SoundSource.BLOCKS, 1.0F, 1.0F);
            level.levelEvent(player, 3004, pos, 0);
            result = unwaxed.get();
        }

        // ---- SHOVEL behaviours: path / extinguish campfire ----
        if (result == null) {
            BlockState pathed = state.getToolModifiedState(ctx, ToolActions.SHOVEL_FLATTEN, false);
            if (pathed != null && level.isEmptyBlock(pos.above())) {
                level.playSound(player, pos, SoundEvents.SHOVEL_FLATTEN, SoundSource.BLOCKS, 1.0F, 1.0F);
                result = pathed;
            }
        }

        if (result != null) {
            if (!level.isClientSide) {
                level.setBlock(pos, result, 11);
                level.gameEvent(GameEvent.BLOCK_CHANGE, pos,
                        GameEvent.Context.of(player, result));
                if (player != null) {
                    ctx.getItemInHand().hurtAndBreak(1, player,
                            p -> p.broadcastBreakEvent(ctx.getHand()));
                }
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }
}
