package com.createblock.mod.storage;

import com.createblock.mod.init.ModStorage;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/**
 * Shared menu for all crate tiers.
 *
 * The GUI shows at most 6 visible rows (54 slots). Tiers with more slots
 * than that are scrolled: 'scrollRow' offsets which row the grid starts
 * at. The container itself always holds the full tier.slots.
 */
public class CrateMenu extends AbstractContainerMenu {

    public static final int COLS = 9;
    public static final int VISIBLE_ROWS = 6;
    public static final int VISIBLE = COLS * VISIBLE_ROWS; // 54

    private final Container container;
    private final int totalSlots;
    private final CrateTier tier;

    // ---- Server constructor ----
    public CrateMenu(int id, Inventory playerInv, CrateBlockEntity be) {
        super(ModStorage.CRATE_MENU.get(), id);
        this.container = be;
        this.totalSlots = be.getContainerSize();
        this.tier = be.getTier();
        layout(playerInv);
    }

    // ---- Client constructor (from network buffer) ----
    public CrateMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        super(ModStorage.CRATE_MENU.get(), id);
        int ordinal = buf.readByte();
        this.tier = CrateTier.values()[ordinal];
        this.totalSlots = tier.slots;
        this.container = new SimpleContainer(totalSlots);
        layout(playerInv);
    }

    public CrateTier getTier() { return tier; }
    public int getTotalSlots() { return totalSlots; }

    private void layout(Inventory playerInv) {
        // Crate slots: we add ALL of them, but position the ones beyond the
        // visible window off-screen (y far below). The screen repositions
        // visible ones on scroll. Simpler + robust: add all, screen shows window.
        int rows = (int) Math.ceil(totalSlots / (double) COLS);
        for (int row = 0; row < rows; row++) {
            for (int col = 0; col < COLS; col++) {
                int index = row * COLS + col;
                if (index >= totalSlots) break;
                this.addSlot(new CrateSlot(container, index,
                        8 + col * 18, 18 + row * 18, this));
            }
        }
        // Player inventory (3 rows) + hotbar, anchored under the visible window.
        int invY = 18 + VISIBLE_ROWS * 18 + 13;
        for (int row = 0; row < 3; row++)
            for (int col = 0; col < 9; col++)
                this.addSlot(new Slot(playerInv, col + row * 9 + 9,
                        8 + col * 18, invY + row * 18));
        for (int col = 0; col < 9; col++)
            this.addSlot(new Slot(playerInv, col, 8 + col * 18, invY + 58));
    }

    @Override
    public boolean stillValid(Player player) {
        return container.stillValid(player);
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            if (index < totalSlots) {
                // from crate -> player
                if (!this.moveItemStackTo(stack, totalSlots, this.slots.size(), true))
                    return ItemStack.EMPTY;
            } else {
                // from player -> crate
                if (!this.moveItemStackTo(stack, 0, totalSlots, false))
                    return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY);
            else slot.setChanged();
        }
        return result;
    }
}
