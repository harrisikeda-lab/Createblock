package com.createblock.mod;

import com.createblock.mod.fluid.ModFluidTypes;
import com.createblock.mod.fluid.ModFluids;
import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.init.ModCreativeTab;
import com.createblock.mod.init.ModItems;
import com.createblock.mod.init.ModStorage;
import com.mojang.logging.LogUtils;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Createblock — custom resource line, alloys, machines, fluid, food,
 * and tiered storage crates for Create-based one-block modpacks.
 *
 * Create is a SOFT dependency: all Create integration is JSON recipes
 * gated by forge:mod_loaded, so the mod builds and runs without Create.
 */
@Mod(Createblock.MODID)
public class Createblock {
    public static final String MODID = "createblock";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Createblock() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        // Blocks before items (items registers the block-items).
        ModFluidTypes.register(bus);
        ModFluids.register(bus);
        ModBlocks.register(bus);
        ModItems.register(bus);
        ModCreativeTab.register(bus);
        ModStorage.register(bus);

        bus.addListener(this::clientSetup);
        LOGGER.info("[Createblock] initialised");
    }

    private void clientSetup(final FMLClientSetupEvent event) {
        event.enqueueWork(() -> MenuScreens.register(
                ModStorage.CRATE_MENU.get(),
                com.createblock.mod.storage.CrateScreen::new));
    }
}
