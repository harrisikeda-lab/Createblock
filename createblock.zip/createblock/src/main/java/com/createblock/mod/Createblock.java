package com.createblock.mod;

import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.init.ModCreativeTab;
import com.createblock.mod.init.ModItems;
import com.createblock.mod.fluid.ModFluidTypes;
import com.createblock.mod.fluid.ModFluids;
import com.mojang.logging.LogUtils;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import org.slf4j.Logger;

/**
 * Createblock — custom resource line, alloys, machines and food
 * for Create-based one-block modpacks.
 *
 * Create is a SOFT dependency: everything here works without it.
 * Create-specific recipes live in data/createblock/recipes/compat/
 * and simply fail to load (harmlessly) if Create isn't installed.
 */
@Mod(Createblock.MODID)
public class Createblock {
    public static final String MODID = "createblock";
    public static final Logger LOGGER = LogUtils.getLogger();

    public Createblock() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();

        // Order matters: items registers block-items, so blocks first.
        ModFluidTypes.register(bus);
        ModFluids.register(bus);
        ModBlocks.register(bus);
        ModItems.register(bus);
        ModCreativeTab.register(bus);

        LOGGER.info("[Createblock] initialised");
    }
}
