package com.createblock.mod.storage;

/**
 * The seven crate tiers. Each stores a number of UNIQUE item types
 * (slots), doubling from the wood base. Higher tiers also allow a
 * bigger max stack size via stack upgrades.
 */
public enum CrateTier {
    WOOD("wood", 9),
    COPPER("copper", 18),
    IRON("iron", 36),
    GOLD("gold", 72),
    DIAMOND("diamond", 144),
    NETHERITE("netherite", 288),
    CREATEBLOCK("createblock", 576);

    public final String id;
    public final int slots;

    CrateTier(String id, int slots) {
        this.id = id;
        this.slots = slots;
    }

    /** Rows of 9 for the GUI (rounded up). */
    public int rows() {
        return (int) Math.ceil(slots / 9.0);
    }
}
