package com.createblock.mod.item;

import com.createblock.mod.init.ModItems;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.Tier;
import net.minecraft.world.level.block.Block;
import net.minecraft.tags.TagKey;
import net.minecraftforge.common.TierSortingRegistry;
import net.minecraft.resources.ResourceLocation;
import com.createblock.mod.Createblock;

import java.util.List;
import java.util.function.Supplier;

/**
 * Custom tool tiers.
 *
 * CREATEBLOCK  — between diamond and netherite. Solid mid-late tool.
 * ALLOY        — the endgame tier used by the Paxel. Very fast, very
 *                durable, high harvest level.
 */
public class ModTiers {

    public static final Tier CREATEBLOCK = TierSortingRegistry.registerTier(
            new ForgeTier(
                    /* level        */ 3,
                    /* uses         */ 1800,
                    /* speed        */ 9.0F,
                    /* attackDamage */ 3.5F,
                    /* enchantValue */ 18,
                    /* tag          */ net.minecraft.tags.BlockTags.NEEDS_DIAMOND_TOOL,
                    () -> Ingredient.of(ModItems.INGOT.get())),
            new ResourceLocation(Createblock.MODID, "createblock"),
            List.of(net.minecraft.world.item.Tiers.DIAMOND),   // after diamond
            List.of(net.minecraft.world.item.Tiers.NETHERITE)  // before netherite
    );

    public static final Tier ALLOY = TierSortingRegistry.registerTier(
            new ForgeTier(
                    /* level        */ 4,
                    /* uses         */ 4096,
                    /* speed        */ 14.0F,
                    /* attackDamage */ 6.0F,
                    /* enchantValue */ 22,
                    /* tag          */ net.minecraft.tags.BlockTags.NEEDS_DIAMOND_TOOL,
                    () -> Ingredient.of(ModItems.ALLOY_INGOT.get())),
            new ResourceLocation(Createblock.MODID, "alloy"),
            List.of(net.minecraft.world.item.Tiers.NETHERITE),  // after netherite
            List.of()
    );

    /** Minimal Tier implementation (Forge's ForgeTier lives in forge, but we
     *  define our own to avoid version drift). */
    public record ForgeTier(int level, int uses, float speed, float attackDamage,
                            int enchantValue, TagKey<Block> tag,
                            Supplier<Ingredient> repairIngredient) implements Tier {
        @Override public int getUses() { return uses; }
        @Override public float getSpeed() { return speed; }
        @Override public float getAttackDamageBonus() { return attackDamage; }
        @Override public int getLevel() { return level; }
        @Override public int getEnchantmentValue() { return enchantValue; }
        @Override public Ingredient getRepairIngredient() { return repairIngredient.get(); }
        @Override public TagKey<Block> getTag() { return tag; }
    }
}
