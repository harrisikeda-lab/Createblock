package com.createblock.mod.storage;

import com.createblock.mod.Createblock;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

/**
 * Scrolling storage screen for all crate tiers.
 *
 * Approach (same as the vanilla creative inventory): the menu contains
 * every crate slot. We show a 9x6 window. On scroll we move each crate
 * slot's y so the current window's rows sit in view and everything else
 * is pushed far off-screen (so it can't be clicked or rendered).
 */
public class CrateScreen extends AbstractContainerScreen<CrateMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(Createblock.MODID, "textures/gui/crate.png");

    private static final int COLS = 9;
    private static final int VISIBLE_ROWS = 6;
    private static final int SLOT = 18;
    private static final int GRID_TOP = 18;   // y of the first visible row
    private static final int OFFSCREEN = -2000;

    private final int totalRows;
    private final boolean scrollable;
    private int scrollRow = 0;         // top visible row
    private boolean isDragging = false;

    public CrateScreen(CrateMenu menu, Inventory playerInv, Component title) {
        super(menu, playerInv, title);
        this.totalRows = (int) Math.ceil(menu.getTotalSlots() / (double) COLS);
        this.scrollable = totalRows > VISIBLE_ROWS;
        this.imageWidth = 176;
        this.imageHeight = 114 + VISIBLE_ROWS * SLOT + 4; // header + grid + player inv
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void init() {
        super.init();
        repositionSlots();
    }

    private int maxScrollRow() {
        return Math.max(0, totalRows - VISIBLE_ROWS);
    }

    /** Move crate slots according to scrollRow; hide the rest off-screen. */
    private void repositionSlots() {
        int total = menu.getTotalSlots();
        for (int i = 0; i < total; i++) {
            Slot slot = menu.slots.get(i);
            int row = i / COLS;
            int col = i % COLS;
            int visibleRow = row - scrollRow;
            if (visibleRow >= 0 && visibleRow < VISIBLE_ROWS) {
                setSlotPos(slot, 8 + col * SLOT, GRID_TOP + visibleRow * SLOT);
            } else {
                setSlotPos(slot, 8 + col * SLOT, OFFSCREEN);
            }
        }
    }

    // Slot.x/y are final in vanilla; Forge exposes no setter, so we reflect
    // once. This is the standard trick for scrolling slot grids.
    private static java.lang.reflect.Field SX, SY;
    static {
        try {
            SX = Slot.class.getField("x");
            SY = Slot.class.getField("y");
        } catch (NoSuchFieldException e) {
            try { // SRG-mapped fallback
                SX = Slot.class.getDeclaredField("f_40220_");
                SY = Slot.class.getDeclaredField("f_40221_");
                SX.setAccessible(true); SY.setAccessible(true);
            } catch (Exception ignored) {}
        }
    }
    private void setSlotPos(Slot slot, int x, int y) {
        try { SX.setInt(slot, x); SY.setInt(slot, y); } catch (Exception ignored) {}
    }

    @Override
    protected void renderBg(GuiGraphics g, float partialTick, int mouseX, int mouseY) {
        RenderSystem.setShaderColor(1, 1, 1, 1);
        int x = (width - imageWidth) / 2;
        int y = (height - imageHeight) / 2;
        // The texture is a generic 9x6 chest-like background.
        g.blit(TEXTURE, x, y, 0, 0, imageWidth, imageHeight);

        // Scrollbar
        if (scrollable) {
            int barX = x + imageWidth - 14;
            int trackTop = y + GRID_TOP;
            int trackH = VISIBLE_ROWS * SLOT;
            g.fill(barX, trackTop, barX + 6, trackTop + trackH, 0xFF373737);
            float frac = maxScrollRow() == 0 ? 0 : (float) scrollRow / maxScrollRow();
            int handleH = 15;
            int handleY = trackTop + (int) (frac * (trackH - handleH));
            g.fill(barX, handleY, barX + 6, handleY + handleH, 0xFFAAAAAA);
        }
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double delta) {
        if (scrollable) {
            int prev = scrollRow;
            scrollRow = Math.max(0, Math.min(maxScrollRow(), scrollRow - (int) Math.signum(delta)));
            if (scrollRow != prev) repositionSlots();
            return true;
        }
        return super.mouseScrolled(mx, my, delta);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (scrollable && isDragging) {
            int y = (height - imageHeight) / 2;
            int trackTop = y + GRID_TOP;
            int trackH = VISIBLE_ROWS * SLOT;
            float frac = (float) ((my - trackTop) / trackH);
            scrollRow = Math.max(0, Math.min(maxScrollRow(), Math.round(frac * maxScrollRow())));
            repositionSlots();
            return true;
        }
        return super.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (scrollable) {
            int x = (width - imageWidth) / 2;
            int y = (height - imageHeight) / 2;
            int barX = x + imageWidth - 14;
            int trackTop = y + GRID_TOP;
            int trackH = VISIBLE_ROWS * SLOT;
            if (mx >= barX && mx <= barX + 6 && my >= trackTop && my <= trackTop + trackH) {
                isDragging = true;
                return true;
            }
        }
        return super.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        isDragging = false;
        return super.mouseReleased(mx, my, button);
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(g);
        super.render(g, mouseX, mouseY, partialTick);
        this.renderTooltip(g, mouseX, mouseY);
    }
}
