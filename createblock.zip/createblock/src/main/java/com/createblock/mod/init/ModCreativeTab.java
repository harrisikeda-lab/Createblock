package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.init.ModStorage;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

/** The Createblock creative tab (modern 1.20.1 system). */
public class ModCreativeTab {

    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, Createblock.MODID);

    public static final RegistryObject<CreativeModeTab> CREATEBLOCK_TAB = TABS.register("createblock_tab",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.createblock"))
                    .icon(() -> new ItemStack(ModItems.INGOT.get()))
                    .displayItems((params, output) -> {
                        // Resources
                        output.accept(ModItems.RAW_ORE.get());
                        output.accept(ModItems.INGOT.get());
                        output.accept(ModItems.NUGGET.get());
                        output.accept(ModItems.DUST.get());
                        output.accept(ModItems.PLATE.get());
                        output.accept(ModItems.GEM.get());
                        output.accept(ModItems.ALLOY_INGOT.get());
                        output.accept(ModItems.ALLOY_NUGGET.get());
                        // Tools
                        output.accept(ModItems.SWORD.get());
                        output.accept(ModItems.PICKAXE.get());
                        output.accept(ModItems.AXE.get());
                        output.accept(ModItems.SHOVEL.get());
                        output.accept(ModItems.HOE.get());
                        output.accept(ModItems.PAXEL.get());
                        // Food
                        output.accept(ModItems.BERRY.get());
                        output.accept(ModItems.ENERGY_BAR.get());
                        output.accept(ModItems.GOLDEN_SNACK.get());
                        output.accept(ModItems.STEW.get());
                        output.accept(ModItems.SANDWICH.get());
                        // Blocks
                        output.accept(ModBlocks.BLOCK.get());
                        output.accept(ModBlocks.RAW_BLOCK.get());
                        output.accept(ModBlocks.ALLOY_BLOCK.get());
                        output.accept(ModBlocks.ORE.get());
                        output.accept(ModBlocks.DEEPSLATE_ORE.get());
                        output.accept(ModBlocks.CASING.get());
                        output.accept(ModBlocks.REINFORCED_BLOCK.get());
                        output.accept(ModBlocks.GENERATOR.get());
                        output.accept(ModBlocks.PROCESSOR.get());
                        output.accept(ModBlocks.INFUSER.get());
                        // Fluid
                        output.accept(ModItems.MOLTEN_CREATEBLOCK_BUCKET.get());
                        // Storage crates
                        for (var e : ModStorage.CRATE_ITEMS.values())
                            output.accept(e.get());
                        output.accept(ModStorage.STACK_UPGRADE.get());
                    })
                    .build());

    public static void register(IEventBus bus) {
        TABS.register(bus);
    }
}
