package com.createblock.mod.storage;

import com.createblock.mod.init.ModStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * One block entity class serves ALL crate tiers. Tier (read from the
 * block) sets slot count; stack upgrades raise the per-slot max stack.
 *
 * We implement the Container item methods directly over a NonNullList,
 * because BaseContainerBlockEntity leaves those abstract.
 */
public class CrateBlockEntity extends BaseContainerBlockEntity {

    private final CrateTier tier;
    private NonNullList<ItemStack> items;
    private int stackMultiplier = 1; // 1 = 64/slot, 2 = 128, ... capped at 16

    public CrateBlockEntity(BlockPos pos, BlockState state, CrateTier tier) {
        super(ModStorage.CRATE_BE.get(), pos, state);
        this.tier = tier;
        this.items = NonNullList.withSize(tier.slots, ItemStack.EMPTY);
    }

    public CrateTier getTier() { return tier; }
    public int getStackMultiplier() { return stackMultiplier; }

    public void setStackMultiplier(int m) {
        this.stackMultiplier = Math.max(1, Math.min(16, m));
        setChanged();
    }

    // ---- Container ----
    @Override public int getContainerSize() { return tier.slots; }

    @Override
    public boolean isEmpty() {
        for (ItemStack s : items) if (!s.isEmpty()) return false;
        return true;
    }

    @Override public ItemStack getItem(int slot) { return items.get(slot); }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack result = ContainerHelper.removeItem(items, slot, amount);
        if (!result.isEmpty()) setChanged();
        return result;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) {
        return ContainerHelper.takeItem(items, slot);
    }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize());
        setChanged();
    }

    @Override
    public void clearContent() { items.clear(); }

    @Override
    public int getMaxStackSize() {
        return Math.min(64 * stackMultiplier, 1024);
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    // ---- BaseContainerBlockEntity ----
    @Override
    protected Component getDefaultName() {
        return Component.translatable("block.createblock." + tier.id + "_crate");
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory playerInv) {
        return new CrateMenu(id, playerInv, this);
    }

    // ---- Save / load ----
    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.items = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        ContainerHelper.loadAllItems(tag, this.items);
        this.stackMultiplier = Math.max(1, tag.getInt("StackMultiplier"));
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        ContainerHelper.saveAllItems(tag, this.items);
        tag.putInt("StackMultiplier", this.stackMultiplier);
    }
}
