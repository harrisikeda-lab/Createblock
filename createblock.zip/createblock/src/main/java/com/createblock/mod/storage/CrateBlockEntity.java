package com.createblock.mod.storage;

import com.createblock.mod.init.ModStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * One block entity class serves ALL crate tiers. The tier is read from
 * the block, which sets slot count and the per-slot max stack multiplier.
 */
public class CrateBlockEntity extends BaseContainerBlockEntity {

    private final CrateTier tier;
    private NonNullList<ItemStack> items;
    // Stack multiplier from upgrades: 1 = normal (64), 2 = 128, 4 = 256...
    private int stackMultiplier = 1;

    public CrateBlockEntity(BlockPos pos, BlockState state, CrateTier tier) {
        super(ModStorage.CRATE_BE.get(), pos, state);
        this.tier = tier;
        this.items = NonNullList.withSize(tier.slots, ItemStack.EMPTY);
    }

    public CrateTier getTier() { return tier; }
    public int getStackMultiplier() { return stackMultiplier; }

    public void setStackMultiplier(int m) {
        this.stackMultiplier = Math.max(1, m);
        setChanged();
    }

    @Override
    public int getMaxStackSize() {
        // base 64 * upgrade multiplier, capped so NBT stays sane
        return Math.min(64 * stackMultiplier, 64 * 16);
    }

    @Override
    public int getContainerSize() { return tier.slots; }

    @Override
    protected NonNullList<ItemStack> getItems() { return items; }

    @Override
    protected void setItems(NonNullList<ItemStack> list) { this.items = list; }

    @Override
    protected Component getDefaultName() {
        return Component.translatable("block.createblock." + tier.id + "_crate");
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory playerInv) {
        return new CrateMenu(id, playerInv, this);
    }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.items = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        net.minecraft.world.ContainerHelper.loadAllItems(tag, this.items);
        this.stackMultiplier = Math.max(1, tag.getInt("StackMultiplier"));
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        net.minecraft.world.ContainerHelper.saveAllItems(tag, this.items);
        tag.putInt("StackMultiplier", this.stackMultiplier);
    }
}
