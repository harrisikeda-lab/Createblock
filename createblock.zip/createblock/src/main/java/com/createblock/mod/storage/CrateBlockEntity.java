package com.createblock.mod.storage;

import com.createblock.mod.init.ModStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.core.NonNullList;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Container;
import net.minecraft.world.ContainerHelper;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BaseContainerBlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * One block entity serves all crate tiers. Base slot count comes from the
 * tier; each stack upgrade adds a ROW (9 slots). Per-slot stack stays the
 * vanilla 64, which avoids all the oversized-stack rendering/merge issues.
 */
public class CrateBlockEntity extends BaseContainerBlockEntity {

    private static final int SLOTS_PER_UPGRADE = 9;
    private static final int MAX_EXTRA_ROWS = 45;   // very high cap (+405 slots)

    private final CrateTier tier;
    private NonNullList<ItemStack> items;
    private int extraRows = 0;

    // Syncs extraRows + tier to the client menu.
    private final ContainerData data = new ContainerData() {
        @Override public int get(int i) { return i == 0 ? extraRows : tier.ordinal(); }
        @Override public void set(int i, int v) { if (i == 0) extraRows = Math.max(0, Math.min(MAX_EXTRA_ROWS, v)); }
        @Override public int getCount() { return 2; }
    };

    public CrateBlockEntity(BlockPos pos, BlockState state, CrateTier tier) {
        super(ModStorage.CRATE_BE.get(), pos, state);
        this.tier = tier;
        this.items = NonNullList.withSize(tier.slots, ItemStack.EMPTY);
    }

    public CrateTier getTier() { return tier; }
    public ContainerData getData() { return data; }
    public int getExtraRows() { return extraRows; }
    public int getBaseSlots() { return tier.slots; }
    public int getMaxExtraRows() { return MAX_EXTRA_ROWS; }

    /** Add one upgrade row, growing the item list without losing contents. */
    public boolean addUpgradeRow() {
        if (extraRows >= MAX_EXTRA_ROWS) return false;
        extraRows++;
        NonNullList<ItemStack> bigger = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        for (int i = 0; i < items.size() && i < bigger.size(); i++) bigger.set(i, items.get(i));
        this.items = bigger;
        setChanged();
        return true;
    }

    // ---- Container ----
    @Override public int getContainerSize() { return tier.slots + extraRows * SLOTS_PER_UPGRADE; }

    @Override
    public boolean isEmpty() {
        for (ItemStack s : items) if (!s.isEmpty()) return false;
        return true;
    }

    @Override public ItemStack getItem(int slot) { return items.get(slot); }

    @Override
    public ItemStack removeItem(int slot, int amount) {
        ItemStack result = ContainerHelper.removeItem(items, slot, amount);
        if (!result.isEmpty()) setChanged();
        return result;
    }

    @Override
    public ItemStack removeItemNoUpdate(int slot) { return ContainerHelper.takeItem(items, slot); }

    @Override
    public void setItem(int slot, ItemStack stack) {
        items.set(slot, stack);
        if (stack.getCount() > getMaxStackSize()) stack.setCount(getMaxStackSize());
        setChanged();
    }

    @Override public void clearContent() { items.clear(); }

    @Override
    public boolean stillValid(Player player) {
        return Container.stillValidBlockEntity(this, player);
    }

    // ---- BaseContainerBlockEntity ----
    @Override
    protected Component getDefaultName() {
        return Component.translatable("block.createblock." + tier.id + "_crate");
    }

    @Override
    protected AbstractContainerMenu createMenu(int id, Inventory playerInv) {
        return new CrateMenu(id, playerInv, this);
    }

    // ---- Save / load ----
    @Override
    public void load(CompoundTag tag) {
        this.extraRows = Math.max(0, Math.min(MAX_EXTRA_ROWS, tag.getInt("ExtraRows")));
        this.items = NonNullList.withSize(getContainerSize(), ItemStack.EMPTY);
        super.load(tag);
        ContainerHelper.loadAllItems(tag, this.items);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putInt("ExtraRows", this.extraRows);
        ContainerHelper.saveAllItems(tag, this.items);
    }
}
