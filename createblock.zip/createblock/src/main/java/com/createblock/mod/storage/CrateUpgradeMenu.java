package com.createblock.mod.storage;

import com.createblock.mod.init.ModStorage;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.ContainerLevelAccess;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * The "Apply Upgrade" screen's menu. No item slots — just a button that,
 * when clicked, consumes one stack-upgrade item from the player and
 * doubles the crate's multiplier (server-side, via clickMenuButton).
 */
public class CrateUpgradeMenu extends AbstractContainerMenu {

    private final ContainerLevelAccess access;
    private final ContainerData data;      // [0] = multiplier, [1] = tier ordinal
    private BlockPos pos;

    // Server
    public CrateUpgradeMenu(int id, Inventory playerInv, CrateBlockEntity be) {
        super(ModStorage.CRATE_UPGRADE_MENU.get(), id);
        this.access = ContainerLevelAccess.create(be.getLevel(), be.getBlockPos());
        this.pos = be.getBlockPos();
        this.data = new SimpleContainerData(2);
        this.data.set(0, be.getStackMultiplier());
        this.data.set(1, be.getTier().ordinal());
        addDataSlots(this.data);
    }

    // Client
    public CrateUpgradeMenu(int id, Inventory playerInv, FriendlyByteBuf buf) {
        super(ModStorage.CRATE_UPGRADE_MENU.get(), id);
        this.access = ContainerLevelAccess.NULL;
        this.data = new SimpleContainerData(2);
        this.pos = buf.readBlockPos();
        addDataSlots(this.data);
    }

    public int getMultiplier() { return data.get(0); }
    public CrateTier getTier() { return CrateTier.values()[Math.max(0, Math.min(CrateTier.values().length-1, data.get(1)))]; }

    @Override
    public boolean clickMenuButton(Player player, int buttonId) {
        if (buttonId == 0) {
            access.execute((level, p) -> {
                BlockEntity be = level.getBlockEntity(p);
                if (be instanceof CrateBlockEntity crate) {
                    int cur = crate.getStackMultiplier();
                    if (cur >= 16) return;
                    // find and consume one upgrade item
                    ItemStack upgrade = new ItemStack(ModStorage.STACK_UPGRADE.get());
                    int slot = player.getInventory().findSlotMatchingItem(upgrade);
                    if (slot >= 0 || player.getAbilities().instabuild) {
                        if (slot >= 0 && !player.getAbilities().instabuild)
                            player.getInventory().removeItem(slot, 1);
                        crate.setStackMultiplier(cur * 2);
                        data.set(0, crate.getStackMultiplier());
                        level.playSound(null, p, net.minecraft.sounds.SoundEvents.ANVIL_USE,
                                net.minecraft.sounds.SoundSource.BLOCKS, 0.6F, 1.4F);
                    }
                }
            });
            return true;
        }
        return false;
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) { return ItemStack.EMPTY; }

    @Override
    public boolean stillValid(Player player) {
        return access.evaluate((level, p) ->
            level.getBlockEntity(p) instanceof CrateBlockEntity, true);
    }
}
