package com.createblock.mod.machine;

import com.createblock.mod.init.ModMachines;
import com.createblock.mod.init.ModRecipes;
import com.createblock.mod.recipe.InfuserRecipe;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.Containers;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.common.util.LazyOptional;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.Optional;

/** Infuser: two inputs (slots 0,1) -> output (slot 2) via InfuserRecipe. */
public class InfuserBlockEntity extends BlockEntity implements net.minecraft.world.MenuProvider {

    private final ItemStackHandler items = new ItemStackHandler(3) {
        @Override protected void onContentsChanged(int slot) { setChanged(); }
        @Override public boolean isItemValid(int slot, @NotNull ItemStack stack) { return slot == 0 || slot == 1; }
    };
    private final LazyOptional<IItemHandler> handler = LazyOptional.of(() -> items);

    private int progress;
    private int maxProgress = 200;

    private final ContainerData data = new ContainerData() {
        @Override public int get(int i) { return i == 0 ? progress : maxProgress; }
        @Override public void set(int i, int v) { if (i==0) progress=v; else maxProgress=v; }
        @Override public int getCount() { return 2; }
    };

    public InfuserBlockEntity(BlockPos pos, BlockState state) {
        super(ModMachines.INFUSER_BE.get(), pos, state);
    }

    public ContainerData getData() { return data; }
    public ItemStackHandler getItems() { return items; }

    public static void tick(Level level, BlockPos pos, BlockState state, InfuserBlockEntity be) {
        if (level.isClientSide) return;
        Optional<InfuserRecipe> recipe = be.getRecipe();
        if (recipe.isPresent() && be.canOutput(recipe.get())) {
            be.maxProgress = recipe.get().getTime();
            be.progress++;
            be.setChanged();
            if (be.progress >= be.maxProgress) {
                be.craft(recipe.get());
                be.progress = 0;
            }
            level.sendBlockUpdated(pos, state, state, 3);
        } else {
            if (be.progress != 0) { be.progress = 0; be.setChanged(); }
        }
    }

    private SimpleContainer asContainer() {
        SimpleContainer c = new SimpleContainer(3);
        for (int i = 0; i < 3; i++) c.setItem(i, items.getStackInSlot(i));
        return c;
    }

    private Optional<InfuserRecipe> getRecipe() {
        if (level == null) return Optional.empty();
        return level.getRecipeManager().getRecipeFor(
                ModRecipes.INFUSER_TYPE.get(), asContainer(), level);
    }

    private boolean canOutput(InfuserRecipe r) {
        ItemStack result = r.getResultItem(level.registryAccess());
        ItemStack out = items.getStackInSlot(2);
        if (items.getStackInSlot(0).isEmpty() || items.getStackInSlot(1).isEmpty()) return false;
        if (out.isEmpty()) return true;
        return ItemStack.isSameItem(out, result)
                && out.getCount() + result.getCount() <= out.getMaxStackSize();
    }

    private void craft(InfuserRecipe r) {
        ItemStack result = r.getResultItem(level.registryAccess());
        items.getStackInSlot(0).shrink(1);
        items.getStackInSlot(1).shrink(1);
        ItemStack out = items.getStackInSlot(2);
        if (out.isEmpty()) items.setStackInSlot(2, result.copy());
        else out.grow(result.getCount());
    }

    @Override public Component getDisplayName() { return Component.translatable("block.createblock.infuser"); }

    @Nullable @Override
    public AbstractContainerMenu createMenu(int id, Inventory inv, Player p) {
        return new InfuserMenu(id, inv, this, this.data);
    }

    @Override
    public @NotNull <T> LazyOptional<T> getCapability(@NotNull Capability<T> cap, @Nullable Direction side) {
        if (cap == ForgeCapabilities.ITEM_HANDLER) return handler.cast();
        return super.getCapability(cap, side);
    }
    @Override public void invalidateCaps() { super.invalidateCaps(); handler.invalidate(); }

    public void drops() {
        SimpleContainer inv = new SimpleContainer(items.getSlots());
        for (int i = 0; i < items.getSlots(); i++) inv.setItem(i, items.getStackInSlot(i));
        Containers.dropContents(this.level, this.worldPosition, inv);
    }

    @Override protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("Inv", items.serializeNBT());
        tag.putInt("Progress", progress);
    }
    @Override public void load(CompoundTag tag) {
        super.load(tag);
        items.deserializeNBT(tag.getCompound("Inv"));
        progress = tag.getInt("Progress");
    }
}
