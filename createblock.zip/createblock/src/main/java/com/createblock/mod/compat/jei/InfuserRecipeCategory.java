package com.createblock.mod.compat.jei;

import com.createblock.mod.Createblock;
import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.recipe.InfuserRecipe;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

public class InfuserRecipeCategory implements IRecipeCategory<InfuserRecipe> {

    public static final ResourceLocation UID = new ResourceLocation(Createblock.MODID, "infusing");
    public static final RecipeType<InfuserRecipe> TYPE =
            RecipeType.create(Createblock.MODID, "infusing", InfuserRecipe.class);

    private final IDrawable background;
    private final IDrawable icon;

    public InfuserRecipeCategory(IGuiHelper helper) {
        this.background = helper.createBlankDrawable(120, 40);
        this.icon = helper.createDrawableItemStack(new ItemStack(ModBlocks.INFUSER.get()));
    }

    @Override public RecipeType<InfuserRecipe> getRecipeType() { return TYPE; }
    @Override public Component getTitle() { return Component.translatable("block.createblock.infuser"); }
    @Override public IDrawable getBackground() { return background; }
    @Override public IDrawable getIcon() { return icon; }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, InfuserRecipe recipe, mezz.jei.api.recipe.IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 6, 12).addIngredients(recipe.getInputA());
        builder.addSlot(RecipeIngredientRole.INPUT, 30, 12).addIngredients(recipe.getInputB());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 96, 12)
                .addItemStack(recipe.getResultItem(RegistryAccess.EMPTY));
    }
}
