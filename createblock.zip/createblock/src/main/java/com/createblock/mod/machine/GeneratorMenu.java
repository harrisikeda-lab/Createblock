package com.createblock.mod.machine;

import com.createblock.mod.init.ModMachines;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class GeneratorMenu extends AbstractContainerMenu {

    private final GeneratorBlockEntity be;
    private final ContainerData data;

    public GeneratorMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, getBE(inv, buf), new SimpleContainerData(3));
    }

    public GeneratorMenu(int id, Inventory inv, GeneratorBlockEntity be, ContainerData data) {
        super(ModMachines.GENERATOR_MENU.get(), id);
        this.be = be;
        this.data = data;
        IItemHandler h = be.getItems();
        this.addSlot(new SlotItemHandler(h, 0, 56, 53));  // fuel
        this.addSlot(new SlotItemHandler(h, 1, 116, 35) { // output
            @Override public boolean mayPlace(ItemStack s) { return false; }
        });
        addPlayerInventory(inv);
        addDataSlots(data);
    }

    private static GeneratorBlockEntity getBE(Inventory inv, FriendlyByteBuf buf) {
        BlockEntity be = inv.player.level().getBlockEntity(buf.readBlockPos());
        return (GeneratorBlockEntity) be;
    }

    public boolean isLit() { return data.get(0) > 0; }
    public int getLitScaled() {
        int t = data.get(0), d = data.get(1);
        return d == 0 ? 0 : t * 13 / d;
    }
    public int getProgressScaled() {
        int p = data.get(2);
        int max = com.createblock.mod.Config.generatorTicksPerItem;
        return max == 0 ? 0 : p * 24 / max;
    }

    private void addPlayerInventory(Inventory inv) {
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                this.addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 84 + r * 18));
        for (int c = 0; c < 9; c++)
            this.addSlot(new Slot(inv, c, 8 + c * 18, 142));
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            int machineSlots = 2;
            if (index < machineSlots) {
                if (!this.moveItemStackTo(stack, machineSlots, this.slots.size(), true))
                    return ItemStack.EMPTY;
            } else {
                if (!this.moveItemStackTo(stack, 0, 1, false))  // only into fuel
                    return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return be != null && !be.isRemoved()
                && player.distanceToSqr(be.getBlockPos().getX() + 0.5,
                    be.getBlockPos().getY() + 0.5, be.getBlockPos().getZ() + 0.5) <= 64.0;
    }
}
