package com.createblock.mod;

import net.minecraftforge.common.ForgeConfigSpec;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.config.ModConfigEvent;

/**
 * Forge-native config. Generates config/createblock-common.toml.
 * No external library required.
 */
@Mod.EventBusSubscriber(modid = Createblock.MODID, bus = Mod.EventBusSubscriber.Bus.MOD)
public class Config {

    public static final ForgeConfigSpec SPEC;

    // --- Crate settings ---
    public static final ForgeConfigSpec.IntValue CRATE_MAX_EXTRA_ROWS;
    public static final ForgeConfigSpec.IntValue CRATE_SLOTS_PER_UPGRADE;

    // --- Machine settings ---
    public static final ForgeConfigSpec.IntValue GENERATOR_TICKS_PER_ITEM;
    public static final ForgeConfigSpec.IntValue PROCESSOR_TICKS;
    public static final ForgeConfigSpec.IntValue INFUSER_TICKS;

    // --- Loot ---
    public static final ForgeConfigSpec.BooleanValue ENABLE_CHEST_LOOT;

    // live values (read these in code)
    public static int crateMaxExtraRows = 45;
    public static int crateSlotsPerUpgrade = 9;
    public static int generatorTicksPerItem = 200;
    public static int processorTicks = 200;
    public static int infuserTicks = 200;
    public static boolean enableChestLoot = true;

    static {
        ForgeConfigSpec.Builder b = new ForgeConfigSpec.Builder();

        b.push("crates");
        CRATE_MAX_EXTRA_ROWS = b
                .comment("Maximum extra rows a crate can gain from stack upgrades (9 slots each).")
                .defineInRange("maxExtraRows", 45, 0, 200);
        CRATE_SLOTS_PER_UPGRADE = b
                .comment("Slots added per upgrade.")
                .defineInRange("slotsPerUpgrade", 9, 1, 9);
        b.pop();

        b.push("machines");
        GENERATOR_TICKS_PER_ITEM = b
                .comment("Ticks of fuel burn per item the Generator produces (lower = faster).")
                .defineInRange("generatorTicksPerItem", 200, 20, 6000);
        PROCESSOR_TICKS = b
                .comment("Default ticks for a Processor recipe.")
                .defineInRange("processorTicks", 200, 20, 6000);
        INFUSER_TICKS = b
                .comment("Default ticks for an Infuser recipe.")
                .defineInRange("infuserTicks", 200, 20, 6000);
        b.pop();

        b.push("loot");
        ENABLE_CHEST_LOOT = b
                .comment("Inject Createblock items into vanilla chest loot.")
                .define("enableChestLoot", true);
        b.pop();

        SPEC = b.build();
    }

    @SubscribeEvent
    static void onLoad(final ModConfigEvent event) {
        if (event.getConfig().getSpec() != SPEC) return;
        crateMaxExtraRows = CRATE_MAX_EXTRA_ROWS.get();
        crateSlotsPerUpgrade = CRATE_SLOTS_PER_UPGRADE.get();
        generatorTicksPerItem = GENERATOR_TICKS_PER_ITEM.get();
        processorTicks = PROCESSOR_TICKS.get();
        infuserTicks = INFUSER_TICKS.get();
        enableChestLoot = ENABLE_CHEST_LOOT.get();
    }
}
