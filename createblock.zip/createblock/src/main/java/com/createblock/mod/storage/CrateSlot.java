package com.createblock.mod.storage;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;

/**
 * A plain crate slot. Stack size is the vanilla 64 — capacity scales by
 * adding more slots (via upgrades), not bigger stacks, so nothing fights
 * Minecraft's stack-size assumptions.
 */
public class CrateSlot extends Slot {
    public CrateSlot(Container container, int index, int x, int y, CrateMenu menu) {
        super(container, index, x, y);
    }
}
