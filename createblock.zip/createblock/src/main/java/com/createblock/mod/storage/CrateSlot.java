package com.createblock.mod.storage;

import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** A slot whose max stack follows the crate's stack-upgrade multiplier. */
public class CrateSlot extends Slot {
    private final CrateMenu menu;

    public CrateSlot(Container container, int index, int x, int y, CrateMenu menu) {
        super(container, index, x, y);
        this.menu = menu;
    }

    @Override
    public int getMaxStackSize() {
        return this.container.getMaxStackSize();
    }

    @Override
    public int getMaxStackSize(ItemStack stack) {
        return Math.min(this.getMaxStackSize(), stack.getMaxStackSize() * multiplier());
    }

    private int multiplier() {
        if (this.container instanceof CrateBlockEntity be) return be.getStackMultiplier();
        return 1;
    }
}
