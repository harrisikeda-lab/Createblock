package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.recipe.InfuserRecipe;
import com.createblock.mod.recipe.ProcessorRecipe;
import net.minecraft.world.SimpleContainer;
import net.minecraft.world.item.crafting.RecipeSerializer;
import net.minecraft.world.item.crafting.RecipeType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModRecipes {

    public static final DeferredRegister<RecipeSerializer<?>> SERIALIZERS =
            DeferredRegister.create(ForgeRegistries.RECIPE_SERIALIZERS, Createblock.MODID);
    public static final DeferredRegister<RecipeType<?>> TYPES =
            DeferredRegister.create(ForgeRegistries.RECIPE_TYPES, Createblock.MODID);

    // Processor
    public static final RegistryObject<RecipeSerializer<ProcessorRecipe>> PROCESSOR_SERIALIZER =
            SERIALIZERS.register("processing", ProcessorRecipe.Serializer::new);
    public static final RegistryObject<RecipeType<ProcessorRecipe>> PROCESSOR_TYPE =
            TYPES.register("processing", () -> new RecipeType<ProcessorRecipe>() {
                @Override public String toString() { return "createblock:processing"; }
            });

    // Infuser
    public static final RegistryObject<RecipeSerializer<InfuserRecipe>> INFUSER_SERIALIZER =
            SERIALIZERS.register("infusing", InfuserRecipe.Serializer::new);
    public static final RegistryObject<RecipeType<InfuserRecipe>> INFUSER_TYPE =
            TYPES.register("infusing", () -> new RecipeType<InfuserRecipe>() {
                @Override public String toString() { return "createblock:infusing"; }
            });

    public static void register(IEventBus bus) {
        SERIALIZERS.register(bus);
        TYPES.register(bus);
    }
}
