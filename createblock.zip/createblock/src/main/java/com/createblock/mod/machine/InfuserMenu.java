package com.createblock.mod.machine;

import com.createblock.mod.init.ModMachines;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.ContainerData;
import net.minecraft.world.inventory.SimpleContainerData;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.items.SlotItemHandler;

public class InfuserMenu extends AbstractContainerMenu {

    private final InfuserBlockEntity be;
    private final ContainerData data;

    public InfuserMenu(int id, Inventory inv, FriendlyByteBuf buf) {
        this(id, inv, getBE(inv, buf), new SimpleContainerData(2));
    }

    public InfuserMenu(int id, Inventory inv, InfuserBlockEntity be, ContainerData data) {
        super(ModMachines.INFUSER_MENU.get(), id);
        this.be = be;
        this.data = data;
        IItemHandler h = be.getItems();
        this.addSlot(new SlotItemHandler(h, 0, 44, 35));
        this.addSlot(new SlotItemHandler(h, 1, 68, 35));
        this.addSlot(new SlotItemHandler(h, 2, 120, 35) {
            @Override public boolean mayPlace(ItemStack st) { return false; }
        });
        addPlayerInventory(inv);
        addDataSlots(data);
    }

    private static InfuserBlockEntity getBE(Inventory inv, FriendlyByteBuf buf) {
        BlockEntity b = inv.player.level().getBlockEntity(buf.readBlockPos());
        return (InfuserBlockEntity) b;
    }

    public int getProgressScaled() {
        int p = data.get(0), m = data.get(1);
        return m == 0 ? 0 : p * 24 / m;
    }

    private void addPlayerInventory(Inventory inv) {
        for (int r = 0; r < 3; r++)
            for (int c = 0; c < 9; c++)
                this.addSlot(new Slot(inv, c + r * 9 + 9, 8 + c * 18, 84 + r * 18));
        for (int c = 0; c < 9; c++)
            this.addSlot(new Slot(inv, c, 8 + c * 18, 142));
    }

    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        ItemStack result = ItemStack.EMPTY;
        Slot slot = this.slots.get(index);
        if (slot != null && slot.hasItem()) {
            ItemStack stack = slot.getItem();
            result = stack.copy();
            int machineSlots = 3;
            if (index < machineSlots) {
                if (!this.moveItemStackTo(stack, machineSlots, this.slots.size(), true))
                    return ItemStack.EMPTY;
            } else {
                if (!this.moveItemStackTo(stack, 0, 2, false))
                    return ItemStack.EMPTY;
            }
            if (stack.isEmpty()) slot.set(ItemStack.EMPTY); else slot.setChanged();
        }
        return result;
    }

    @Override
    public boolean stillValid(Player player) {
        return be != null && !be.isRemoved()
                && player.distanceToSqr(be.getBlockPos().getX() + 0.5,
                    be.getBlockPos().getY() + 0.5, be.getBlockPos().getZ() + 0.5) <= 64.0;
    }
}
