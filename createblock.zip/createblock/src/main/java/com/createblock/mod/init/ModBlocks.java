package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.block.GeneratorBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraft.util.valueproviders.UniformInt;
import com.createblock.mod.block.BerryCropBlock;
import net.minecraft.world.level.block.LiquidBlock;
import net.minecraft.world.level.material.PushReaction;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** All Createblock blocks. Block-items are registered in ModItems. */
public class ModBlocks {

    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, Createblock.MODID);

    // ---- Storage blocks ----
    public static final RegistryObject<Block> BLOCK = BLOCKS.register("block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(5.0F, 6.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> RAW_BLOCK = BLOCKS.register("raw_block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_CYAN)
                    .strength(5.0F, 6.0F)
                    .sound(SoundType.STONE)
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> ALLOY_BLOCK = BLOCKS.register("alloy_block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_PURPLE)
                    .strength(6.0F, 7.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    // ---- Ores (drop XP like vanilla ores) ----
    public static final RegistryObject<Block> ORE = BLOCKS.register("ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.STONE)
                    .strength(3.0F, 3.0F)
                    .sound(SoundType.STONE)
                    .requiresCorrectToolForDrops(),
                    UniformInt.of(1, 3)));

    public static final RegistryObject<Block> DEEPSLATE_ORE = BLOCKS.register("deepslate_ore",
            () -> new DropExperienceBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DEEPSLATE)
                    .strength(4.5F, 3.0F)
                    .sound(SoundType.DEEPSLATE)
                    .requiresCorrectToolForDrops(),
                    UniformInt.of(1, 3)));

    // ---- Decorative / build ----
    public static final RegistryObject<Block> CASING = BLOCKS.register("casing",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_GRAY)
                    .strength(3.0F, 4.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> REINFORCED_BLOCK = BLOCKS.register("reinforced_block",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_GRAY)
                    .strength(8.0F, 12.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    // ---- Machine-look blocks ----
    public static final RegistryObject<Block> GENERATOR = BLOCKS.register("generator",
            () -> new GeneratorBlock(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_GRAY)
                    .strength(4.0F, 5.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> PROCESSOR = BLOCKS.register("processor",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_GRAY)
                    .strength(4.0F, 5.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    public static final RegistryObject<Block> INFUSER = BLOCKS.register("infuser",
            () -> new Block(BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_GRAY)
                    .strength(4.0F, 5.0F)
                    .sound(SoundType.METAL)
                    .requiresCorrectToolForDrops()));

    // ---- Crop ----
    // No BlockItem: you plant it with the berry (ItemNameBlockItem).
    public static final RegistryObject<Block> BERRY_CROP = BLOCKS.register("berry_crop",
            () -> new BerryCropBlock(BlockBehaviour.Properties.copy(
                    net.minecraft.world.level.block.Blocks.WHEAT)));

    // ---- Fluid block (the liquid you see in the world) ----
    // Registered here but has NO BlockItem (you use the bucket instead).
    public static final RegistryObject<LiquidBlock> MOLTEN_CREATEBLOCK_BLOCK =
            BLOCKS.register("molten_createblock_block",
                    () -> new LiquidBlock(com.createblock.mod.fluid.ModFluids.MOLTEN_CREATEBLOCK,
                            BlockBehaviour.Properties.of()
                                    .mapColor(MapColor.COLOR_CYAN)
                                    .replaceable()
                                    .noCollission()
                                    .strength(100.0F)
                                    .pushReaction(PushReaction.DESTROY)
                                    .noLootTable()
                                    .liquid()
                                    .lightLevel(state -> 12)));

    public static void register(IEventBus bus) {
        BLOCKS.register(bus);
    }
}
