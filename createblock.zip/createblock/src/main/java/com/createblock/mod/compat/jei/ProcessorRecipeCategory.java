package com.createblock.mod.compat.jei;

import com.createblock.mod.Createblock;
import com.createblock.mod.init.ModBlocks;
import com.createblock.mod.recipe.ProcessorRecipe;
import mezz.jei.api.constants.VanillaTypes;
import mezz.jei.api.gui.builder.IRecipeLayoutBuilder;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.helpers.IGuiHelper;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.recipe.RecipeType;
import mezz.jei.api.recipe.category.IRecipeCategory;
import net.minecraft.core.RegistryAccess;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.item.ItemStack;

public class ProcessorRecipeCategory implements IRecipeCategory<ProcessorRecipe> {

    public static final ResourceLocation UID = new ResourceLocation(Createblock.MODID, "processing");
    public static final RecipeType<ProcessorRecipe> TYPE =
            RecipeType.create(Createblock.MODID, "processing", ProcessorRecipe.class);

    private final IDrawable background;
    private final IDrawable icon;

    public ProcessorRecipeCategory(IGuiHelper helper) {
        this.background = helper.createBlankDrawable(120, 40);
        this.icon = helper.createDrawableItemStack(new ItemStack(ModBlocks.PROCESSOR.get()));
    }

    @Override public RecipeType<ProcessorRecipe> getRecipeType() { return TYPE; }
    @Override public Component getTitle() { return Component.translatable("block.createblock.processor"); }
    @Override public IDrawable getBackground() { return background; }
    @Override public IDrawable getIcon() { return icon; }

    @Override
    public void setRecipe(IRecipeLayoutBuilder builder, ProcessorRecipe recipe, mezz.jei.api.recipe.IFocusGroup focuses) {
        builder.addSlot(RecipeIngredientRole.INPUT, 10, 12)
                .addIngredients(recipe.getInput());
        builder.addSlot(RecipeIngredientRole.OUTPUT, 90, 12)
                .addItemStack(recipe.getResultItem(RegistryAccess.EMPTY));
    }
}
