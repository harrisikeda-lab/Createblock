package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.machine.GeneratorBlockEntity;
import com.createblock.mod.machine.InfuserBlockEntity;
import com.createblock.mod.machine.InfuserMenu;
import com.createblock.mod.machine.ProcessorBlockEntity;
import com.createblock.mod.machine.ProcessorMenu;
import com.createblock.mod.machine.GeneratorMenu;
import net.minecraft.world.inventory.MenuType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.common.extensions.IForgeMenuType;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Registration for functional machines (block entities + menus). */
public class ModMachines {

    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, Createblock.MODID);
    public static final DeferredRegister<MenuType<?>> MENUS =
            DeferredRegister.create(ForgeRegistries.MENU_TYPES, Createblock.MODID);

    public static final RegistryObject<BlockEntityType<GeneratorBlockEntity>> GENERATOR_BE =
            BLOCK_ENTITIES.register("generator", () -> BlockEntityType.Builder.of(
                    GeneratorBlockEntity::new, ModBlocks.GENERATOR.get()).build(null));

    public static final RegistryObject<MenuType<GeneratorMenu>> GENERATOR_MENU =
            MENUS.register("generator", () -> IForgeMenuType.create(GeneratorMenu::new));

    public static final RegistryObject<BlockEntityType<ProcessorBlockEntity>> PROCESSOR_BE =
            BLOCK_ENTITIES.register("processor", () -> BlockEntityType.Builder.of(
                    ProcessorBlockEntity::new, ModBlocks.PROCESSOR.get()).build(null));
    public static final RegistryObject<MenuType<ProcessorMenu>> PROCESSOR_MENU =
            MENUS.register("processor", () -> IForgeMenuType.create(ProcessorMenu::new));

    public static final RegistryObject<BlockEntityType<InfuserBlockEntity>> INFUSER_BE =
            BLOCK_ENTITIES.register("infuser", () -> BlockEntityType.Builder.of(
                    InfuserBlockEntity::new, ModBlocks.INFUSER.get()).build(null));
    public static final RegistryObject<MenuType<InfuserMenu>> INFUSER_MENU =
            MENUS.register("infuser", () -> IForgeMenuType.create(InfuserMenu::new));

    public static void register(IEventBus bus) {
        BLOCK_ENTITIES.register(bus);
        MENUS.register(bus);
    }
}
