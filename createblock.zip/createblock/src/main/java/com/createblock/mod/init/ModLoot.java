package com.createblock.mod.init;

import com.createblock.mod.Createblock;
import com.createblock.mod.loot.AddChestLootModifier;
import com.mojang.serialization.Codec;
import net.minecraftforge.common.loot.IGlobalLootModifier;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

/** Registers the global loot modifier codec. */
public class ModLoot {

    public static final DeferredRegister<Codec<? extends IGlobalLootModifier>> LOOT_MODIFIERS =
            DeferredRegister.create(ForgeRegistries.Keys.GLOBAL_LOOT_MODIFIER_SERIALIZERS, Createblock.MODID);

    public static final RegistryObject<Codec<AddChestLootModifier>> ADD_CHEST_LOOT =
            LOOT_MODIFIERS.register("add_chest_loot", () -> AddChestLootModifier.CODEC);

    public static void register(IEventBus bus) {
        LOOT_MODIFIERS.register(bus);
    }
}
