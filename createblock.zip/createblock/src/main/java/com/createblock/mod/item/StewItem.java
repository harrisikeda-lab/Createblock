package com.createblock.mod.item;

import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.item.Item;

/**
 * Stew: returns an empty bowl when eaten (like vanilla soups),
 * and stacks to 1.
 */
public class StewItem extends Item {

    public StewItem(Properties properties) {
        super(properties);
    }

    @Override
    public ItemStack finishUsingItem(ItemStack stack, Level level, LivingEntity entity) {
        ItemStack result = super.finishUsingItem(stack, level, entity);
        // Hand back a bowl; if the stack is gone, replace it with the bowl.
        if (result.isEmpty()) {
            return new ItemStack(Items.BOWL);
        }
        if (entity instanceof net.minecraft.world.entity.player.Player player
                && !player.getAbilities().instabuild) {
            if (!player.getInventory().add(new ItemStack(Items.BOWL))) {
                player.drop(new ItemStack(Items.BOWL), false);
            }
        }
        return result;
    }
}
